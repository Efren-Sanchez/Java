Factura CLI System

    ⚠️ If you're using VS Code, press Ctrl + Shift + V to preview this README correctly.

This program provides a simple and concise way to create "Facturas" (invoices) directly from the terminal.

0. 🧪 Quick Demo (Copy-Paste Example)

Here is a quick example of bulk creating a factura with 3 lines, then printing the loaded data

    crea grupo
    crea linea ln1 0 a 1 5.0 NORMAL
    crea linea ln2 0 a 1 7.12 REDUCIDO
    crea linea ln3 0 a 1 10.0 SUPERREDUCIDO
    crea facturado fo1 Pepe 123
    crea facturante fe1 GUGU a 123 4256157 some@email.com
    crea factura fc1 fe1 fo1 12 0
    gdata

1. 🔡 Escape Codes

The program supports several escape codes to handle complex text inputs:

    Escape	Description

    \s	    Treats the word before and after as one. Example: Maria\ Evvins → "Maria Evvins"

    \n	    Inserts a line break

    \t	    Inserts a tab (Java's tab spacing, not user-defined)

    \' or \"	Prints a single or double quote

    \\\\	Prints a backslash (\\)

2. 🧊 Quotes (Single & Double)

The program also supports grouping data via double quotes,

    Double quotes " : Treat content literally (escape codes won't apply).
    Example: "The \n stays as \n" → printed as-is.

    Single quotes ' : Escape codes are interpreted.
    Example: 'This \"text\" is quoted.' → This "text" is quoted.

3. 🏭 Factories

You can manage data through factories, which walk you through each variable step-by-step.

    Commands like crea and modifica use factories.

    Ideal for beginners or when handling complex objects.

    Strings with spaces must be wrapped in quotes or escaped, but inside factories, this is not required.

4. 📦 Bulking

Many factory commands also support bulk creation for speed.

    Syntax:
    crea [type] [id] [args...]

    Example:
    crea facturante fe1 Pepe 11223344

    Best when creating multiple objects quickly.

    For just one Factura, using the factory might be simpler, and faster in some cases

5. 🧾 Commands List

Run any command without parameters to view usage/help.

    Command	Description

    exit	Closes the program. Prompts for confirmation. Use with caution!
    help	Lists all commands and general help
    clear	Clears the terminal screen
    gdata	Prints global data (default format is XML). Use xml or bnr for JSON

    options	Change settings like default Factura, tab size, auto-exit, etc.

    crea	Creates an object (bulk or via factory)
    borra	Deletes an object (e.g., line, group, etc.)
    modifica	Edits an object (bulk or factory)
    print	Prints an object’s data. Format: xml or bnr (JSON). Default is XML

    saveXml	Saves Factura to /data/xml/[id].xml
    loadXml	Loads Factura from /data/xml/[id].xml (no .xml needed in input)
    saveBnr	Saves Factura to /data/bnr/[id].json
    loadBnr	Loads Factura from /data/bnr/[id].json (no .json needed in input)