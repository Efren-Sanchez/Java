import org.junit.Test;

public class Printifier_TEST {

  public final int linelength = 50;

  @Test
  public void PrintOneLine() {
    System.out.println("-".repeat(linelength));
  }

  @Test
  public void PrintBox() {
  }
}
