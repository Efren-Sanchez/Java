package com.pws.facturas.utils;

import java.time.LocalDateTime;
import java.util.Arrays;

import com.pws.facturas.GlobalDataHolder;
import com.pws.facturas.datatypes.ComlineState;
import com.pws.facturas.datatypes.Factura;
import com.pws.facturas.datatypes.Facturado;
import com.pws.facturas.datatypes.Facturante;
import com.pws.facturas.datatypes.IVA;
import com.pws.facturas.datatypes.LineaDeFactura;
import com.pws.facturas.datatypes.PFloat;

public abstract class Factory {

  public static final int makeGroup(boolean skipExistingPrompt) {
    // create new ? y => factory : n => use existing ? y => enter id : exit factory;

    boolean choicePrompt = prompt1V2("/ <grupo> Crear nuevo grupo?", "s", "n", true);
    if (choicePrompt) {
      Debug.print("| <grupo> New group was created with id: ");
      int gid = GlobalDataHolder.putNewGroup();
      Debug.println(gid + ".");
      ComlineState.success();
      return gid;
    }

    choicePrompt = prompt1V2("| <grupo> Quieres usadr un ya existente?", "s", "n", true);

    if (!skipExistingPrompt && choicePrompt) {
      String groupId = promptEnterData("\\ <grupo> Que grupo va a ser usado?");
      if (GlobalDataHolder.dragGrupo(Integer.parseInt(groupId)) == null) {
        Debug.println("\\ <grupo> Group " + groupId + " not found.");
        ComlineState.fail();
        return -1;
      }
      ComlineState.success();
      try {return Integer.parseInt(groupId);}
      catch (NumberFormatException e) {
        Debug.println(ComlineState.FAIL.getPrint() + "Informacion dada no es un numero.");
        return -1;
      }
    }

    ComlineState.success();
    return -1;
  }

  public static final LineaDeFactura makeLine(boolean skipExistingPrompt, boolean skipExistingPromptGrupo) {
    // LineaDeFactura(String articulo, int cantidad, PFloat precio, IVA iva)
    // create new ? y => factory : n => use existing ? y => enterName : n => exit
    // factory.
    boolean choicePrompt = prompt1V2("/ <linea> Crear nueva linea?", "s", "n", true);
    if (choicePrompt) {
      LineaDeFactura line = new LineaDeFactura();
      // name of article
      String dataPrompt = promptEnterData("| <linea> Que artico tiene?");
      line.setArticulo(dataPrompt);

      // Quantity
      dataPrompt = promptEnterData("| <linea> Cuantos articulos quieres anadir?");
      try {line.setCantidad(Integer.parseInt(dataPrompt)); }
      catch (NumberFormatException e) {
        Debug.println(ComlineState.FAIL.getPrint() + "Informacion dada no es un numero.");
        return null;
      }

      // Price
      dataPrompt = promptEnterData("| <linea> Que precio unitario tiene?");
      try { line.setPrecio(new PFloat(dataPrompt)); }
      catch (NumberFormatException e) {
        Debug.println(ComlineState.FAIL.getPrint() + "Informacion dada no es un numero flotante valido.");
        return null;
      }

      // IVA
      dataPrompt = promptEnterData("| <linea> Que nivel de IVA tiene? [NORMAL, REDUCIDO, SUPERREDUCIDO]");
      line.setIva(IVA.get(dataPrompt));

      // Group
      Debug.println("| <linea> Se necesita un grupo.");
      int groupId = makeGroup(skipExistingPromptGrupo);

      if (groupId == -1) {
        Debug.println("\\ <linea> Ningun grupo usado. Saliendo factory.");
        ComlineState.fail();
        return null;
      }

      // VarName
      dataPrompt = promptEnterData("| <linea> Cual va a ser el nombre identificador de la linea?");
      line.setVarName(dataPrompt);
      

      // Addition.
      ComlineState.success();
      return line;
    }
    choicePrompt = prompt1V2("| <linea> Quieres usar una linea ya existente?", "s", "n", true);

    if (!skipExistingPrompt && choicePrompt) {
      // enter line group
      Debug.println("| <linea> Se necesita un grupo.");
      int groupId = makeGroup(skipExistingPromptGrupo);

      if (groupId == -1) {
        Debug.println("\\ <linea> Ningun grupo usado. Saliendo factory.");
        ComlineState.fail();
        return null;
      }

      // VarName
      String dataPrompt = promptEnterData("| <linea> Cual va a ser el nombre identificador de la linea?");
      LineaDeFactura line = GlobalDataHolder.dragLineaDeGrupo(groupId, dataPrompt);

      if (line == null) {
        Debug.println("\\ <linea> La linea " + dataPrompt + " no existe.");
        ComlineState.fail();
        return null;
      }

      ComlineState.success();
      return line;
    }

    // exit factory;
    ComlineState.success();
    return null;
  }

  public static final Facturado makeFacturado(boolean skipExistingPrompt) {
    // (String nombre, String NifOCif)
    // create new ? y => factory : n => use existing ? y => enterName : n => exit
    // factory.

    boolean choicePrompt = prompt1V2("/ <facturado> Quieres crear un nuevo \"Facturado\"?", "s", "n", true);
    if (choicePrompt) {
      // factory
      Facturado facturado = new Facturado();

      // Name
      String dataPrompt = promptEnterData("| <facturado> Cual va a ser su nombre?");
      facturado.setNombre(dataPrompt);

      // NIF or CIF
      dataPrompt = promptEnterData("| <facturado> Cual es su NIF or CIF?");
      facturado.setNifOCif(dataPrompt);

      // VarName
      dataPrompt = promptEnterData("| <facturado> Cual va a ser el nombre identificador del facturado?");
      facturado.setVarName(dataPrompt);

      // Addition
      ComlineState.success();
      return facturado;
    }

    choicePrompt = prompt1V2("| <facturado> Quieres usar uno ya existente?", "s", "n", true);
    if (!skipExistingPrompt && choicePrompt) {
      // VarName
      String dataPrompt = promptEnterData("| <facturado> Cual va a ser el nombre identificador del facturado?");
      Facturado facturado = GlobalDataHolder.dragFacturado(dataPrompt);

      // get the object
      if (facturado == null) {
        Debug.println("\\ <facturado> El facturado " + dataPrompt + " no existe.");
        ComlineState.fail();
        return null;
      }
      ComlineState.success();
      return facturado;
    }

    // exit factory;
    ComlineState.success();
    return null;
  }

  public static final Facturante makeFacturante(boolean skipExistingPrompt) {
    // (String nombre, String direccion, String CIF, String telefono, String email)
    // create new ? y => factory : n => use existing ? y => enterName : n => exit
    // factory.

    boolean choicePrompt = prompt1V2("/ <facturante> Quieres crear un nuevo \"Facturante\"?", "s", "n", true);
    if (choicePrompt) {
      // factory
      Facturante facturante = new Facturante();

      // Name
      String dataPrompt = promptEnterData("| <facturante> Cual es su nombre?");
      facturante.setNombre(dataPrompt);

      // Direccion
      dataPrompt = promptEnterData("| <facturante> Donde vive?", true);
      facturante.setDireccion(dataPrompt);

      // NIF or CIF
      dataPrompt = promptEnterData("| <facturante> Cual es su NIF o CIF?");
      facturante.setCIF(dataPrompt);

      // Phone Number
      dataPrompt = promptEnterData("| <facturante> Cual es su numero de telefono?");
      facturante.setTelefono(dataPrompt);

      // Email
      dataPrompt = promptEnterData("| <facturante> Cual es su email?");
      facturante.setEmail(dataPrompt);

      // VarName
      dataPrompt = promptEnterData("| <facturante>  Cual va a ser el nombre identificador del facturante?");
      facturante.setVarName(dataPrompt);

      // Addition
      ComlineState.success();
      return facturante;
    }

    choicePrompt = prompt1V2("| <facturante> Quieres usar uno existente?", "s", "n", true);
    if (!skipExistingPrompt && choicePrompt) {
      // VarName
      String dataPrompt = promptEnterData(
          "| <facturante> Cual va a ser el nombre identificador del facturante?");
      Facturante facturante = GlobalDataHolder.dragFacturante(dataPrompt);

      // get the object
      if (facturante == null) {
        Debug.println("| <facturante> El facturante " + dataPrompt + " no existe.");
        ComlineState.fail();
        return null;
      }

      ComlineState.success();
      return facturante;
    }

    // exit factory;
    ComlineState.success();
    return null;
  }

  public static final Factura makeFactura() {
    // (Facturante facturante, Facturado facturado, LocalDateTime fechaYHora, int
    // numeroFactura, LineaDeFactura[] lineasFactura, PFloat totalFactura)
    // create new facturante (facturante prompt).
    // create new factrrado (facturado prompt).
    // create new group of lineas? y => loop craete linea de factura untill DONE
    // prompt : n => add existing? (group prompt.)

    boolean choicePrompt = prompt1V2("/ <factura> Crear nueva \"Factura\"?", "s", "n", true);
    if (choicePrompt) {
      // factory
      Factura factura = new Factura();

      String ldt = LocalDateTime.now().toString();
      Debug.println("| <factura> La fecha y hora se creo: " + ldt);
      factura.setFechaYHora(LocalDateTime.parse(ldt));

      int facturaNum = GlobalDataHolder.getFacturas().length + 1;
      Debug.println("| <factura> El numero de factura se creo: " + facturaNum);
      factura.setNumeroFactura(facturaNum);

      // Facturante
      Debug.println("| <factura> Se necesita un facturante. ");
      factura.setFacurante(makeFacturante(false));

      // Facturado
      Debug.println("| <factura> Se necesita un facturado.");
      factura.setFacturado(makeFacturado(false));

      // lineas de factura
      Debug.println("/ <factura> Se necesita 1 o varois lineas de factura.");
      LineaDeFactura[] grupo = new LineaDeFactura[0];

      while (choicePrompt) {
        choicePrompt = prompt1V2("| <factura> Quieres crear un nuevo grupo con esa linea?", "s", "n", true);
        if (choicePrompt) {
          LineaDeFactura l = makeLine(true, true);
          grupo = Arrays.copyOf(grupo, grupo.length + 1);
          grupo[grupo.length - 1] = l;
        } else  {
          choicePrompt = prompt1V2("| <factura> Quieres usar un grupo ya existente?", "s", "n", true);
          if (choicePrompt) {
            // VarName
            String dataPrompt = promptEnterData("| <factura> Cual es el id del grupo?");
            grupo = GlobalDataHolder.dragGrupo(Integer.parseInt(dataPrompt));
            break;
          }
        }

        if(grupo != null && grupo.length > 0) {
          choicePrompt = prompt1V2("| <factura> Anadir mas lineas?", "s", "n", true);
          if (!choicePrompt) {
            break;
          }
        } else {
          Debug.println("| <factura> Una linea de factura es nececsaria, como minimo.");
        }
      }

      if (grupo == null) {
        Debug.println("\\ <factra> Algo ha pasado mal en la creacion de las lineas.");
        ComlineState.fail();
        return null;
      }
      factura.setLineasFactura(grupo);

      PFloat total = Factura.calculateTotal(grupo);
      Debug.println("| <factura> El total calculado de la factura es: " + total);
      factura.setTotalFactura(total);

      // Addition
      ComlineState.success();
      return factura;
    }

    // exit factory;
    ComlineState.success();
    return null;
  }

  public static final String promptEnterData(String prompt) {
    return promptEnterData(prompt, false);
  }

  public static final String promptEnterData(String prompt, boolean full) {
    String scanLine = "";
    ComlineState.tractor();
    while (scanLine.equals("")) {
      Debug.print(prompt + " ");
      scanLine = Input.read();
      if(scanLine.equals("")) {
        Debug.println(ComlineState.FAIL.getPrint() + "Tienes que introducir datos.");
      }
    }

    if (!full)
      return StringUtils.breakApart(scanLine)[0];
    else
      return scanLine;
  }

  public static final boolean prompt1V2(String prompt, String trueOption, String falseOption, boolean whichIsDefault) {
    // set the edge case output to the default option
    boolean out = whichIsDefault;

    // default both options to lowercase for ease of access
    trueOption = trueOption.toLowerCase();
    falseOption = falseOption.toLowerCase();
    ComlineState.tractor();
    // set up prompt, and signal which is the default option.
    Debug.print(prompt + " (" +
        (whichIsDefault == true ? trueOption.toUpperCase() : trueOption.toLowerCase())
        + " o " +
        (whichIsDefault == false ? falseOption.toUpperCase() : falseOption.toLowerCase()) +
        ") ");

    // begin user input and close it right after.
    String scanLine = Input.read();

    // if they are equal, it will return either true or false depending on which
    // option was inputted,
    // and in every other edge case, the default option is returned.
    if (scanLine.toLowerCase().equals(trueOption))
      return true;
    else if (scanLine.toLowerCase().equals(falseOption))
      return false;
    else
      return out;
  }
}
