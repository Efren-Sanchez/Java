package com.pws.facturas.utils;

import java.util.Arrays;

import com.pws.facturas.Commands.C_Options;

/**
 * Implementation for special string utilitaries.
 * 
 * @author Cirnicianu Ciprian Nicolae
 * @version 1.1
 * @since 1.0
 */
public abstract class StringUtils {
  /**
   * Returns the string between two parts, without them.
   * 
   * @param text  the text to search
   * @param start the first part
   * @param end   the second part
   * @return the text between {@code start} and {@code end}
   */
  public static String getBetween(String text, String start, String end) {
    int startIndex = text.indexOf(start);
    if (startIndex == -1)
      return ""; // Start string not found

    startIndex += start.length();
    int endIndex = text.indexOf(end, startIndex);
    if (endIndex == -1)
      return ""; // End string not found

    return text.substring(startIndex, endIndex);
  }

  /**
   * Retuns the string at a single position. if the selected character is space,
   * it returns the last complete part.
   * 
   * @param buffer the string to search. cant be empty, and its treates as a
   *               literal.
   * @param pos    the position in the string to return the part of.
   * @return the part at that position. (See breakAprart for more info.)
   * @see StringUtils#breakApart(String)
   */
  public static String getWordAtCursor(String buffer, int pos) {
    if (buffer.length() == 0) {
      return "";
    }

    // imagine the characters in the buffer are all literals.
    String[] bapStrings = breakApart(buffer.replace("\"", "'"));

    // If cursor is on a space, move it forward until it reaches a character
    int adjustedCursor = pos;
    while (adjustedCursor < buffer.length() && buffer.charAt(adjustedCursor) == ' ') {
      adjustedCursor++;
    }

    // return the word at the cursor.
    int runningLength = 0;
    for (String word : bapStrings) {
      int wordStart = runningLength;
      int wordEnd = wordStart + word.length();

      if (adjustedCursor >= wordStart && adjustedCursor <= wordEnd) {
        return word;
      }

      runningLength = wordEnd + 1;
    }

    return "";
  }

  /**
   * Takes a string and separates it into parts. each part is either a word
   * separated by space,
   * or a string of characters between {@code " "} or {@code ' '}. it also
   * supports the special characters
   * {@code '\\'}, {@code '\ '}, {@code '\''}, {@code '\"'}, {@code '\n'} and
   * {@code '\t'}.
   * 
   * @param args
   * @return
   */
  public static String[] breakApart(String text) {
    // set up the character buffers
    text = text.trim().replaceAll("\\s+", " ");
    String c0 = "";
    char c1 = 0;
    char[] characters = text.toCharArray();

    // put a space at the end of the text, to make sure that "\" characters are
    // iterated properly.
    if (characters[characters.length - 1] != ' ') {
      characters = Arrays.copyOf(characters, characters.length + 1);
      characters[characters.length - 1] = ' ';
    }

    // initialize the singlequote and doublequote idices with -1, which means, no
    // character of that type was found thus far.
    int singlequoteStart = -1;
    int doublequoteStart = -1;
    StringBuffer finalString = new StringBuffer();

    for (int i = 0; i < characters.length; i++) {
      // roll the combo for the next loop.
      c0 = String.valueOf(characters[i]);
      if (i + 1 < characters.length)
        c1 = characters[i + 1];
      else
        c1 = 0;

      // create a combo using the two stored chars.
      String combo = c0 + c1;

      switch (c0) {
        // if the separation is a space, then replace it with a unit separator unicodee
        // char if no quote was found.
        // else just put the space back.
        case " ":
          if (doublequoteStart == -1 && singlequoteStart == -1)
            finalString.append("\u001F");
          else
            finalString.append(" ");
          break;

        // handle each "\"character. ('\\', '\ ', '\'', '\"', '\n' and '\t')
        case "\\":
          if (singlequoteStart != -1) {
            finalString.append("\\");
            break;
          }
          if (combo.equals("\\\\"))
            finalString.append("\\");
          else if (combo.equals("\\ "))
            finalString.append(" ");
          else if (combo.equals("\\'"))
            finalString.append("'");
          else if (combo.equals("\""))
            finalString.append("\"");
          else if (combo.equals("\\n"))
            finalString.append("\n");
          else if (combo.equals("\\t"))
            finalString.append("\t");
          i++;
          break;
        // singlequote groups all the text inside as one part, and keeps special
        // characters and spaces.
        case "'":
          if (singlequoteStart != -1) {
            singlequoteStart = -1;
            if (singlequoteStart < doublequoteStart)
              doublequoteStart = -1;
          } else
            singlequoteStart = i;
          break;

        // doublequote groups all the text inside as one part, and keeps the characters
        // inside as literals.
        case "\"":
          if (doublequoteStart != -1) {
            doublequoteStart = -1;
            if (doublequoteStart < singlequoteStart)
              singlequoteStart = -1;
          } else
            doublequoteStart = i;
          break;
        default:
          finalString.append(c0);
          break;
      }

      // if we reached the end of the text, but for some reason there are quotes still
      // open, close them properly.
      if (i == characters.length - 1) {
        int smaller = (singlequoteStart < doublequoteStart)
            ? singlequoteStart == -1 ? doublequoteStart : singlequoteStart
            : doublequoteStart == -1 ? singlequoteStart : doublequoteStart;

        if (smaller != -1)
          finalString.append(text.substring(smaller));
      }
    }

    // return all the parts by spliting on the unit separator unicode.
    return finalString.toString().split("\u001F");
  }

  /**
   * Retuns a pretty version of the passed xml code.
   * 
   * @param text the xml code in text form to be prettyfied.
   * @return a string with tabulations and new lines in proper places.
   */
  public static String prettifyXml(String xmlString) {
    StringBuilder prettyXml = new StringBuilder();
    int indentLevel = 0;
    boolean insideTag = false;
    boolean textContentExpected = false;
    int i = 0;
    int length = xmlString.length();

    while (i < length) {
      char currentChar = xmlString.charAt(i);

      if (currentChar == '<') {
        boolean isClosingTag = (i + 1 < length && xmlString.charAt(i + 1) == '/');
        boolean isSelfClosing = (i > 0 && xmlString.charAt(i - 1) == '/');

        // Handle closing tags
        if (isClosingTag) {
          indentLevel--;
          if (!textContentExpected) {
            prettyXml.append(System.lineSeparator());
            appendIndent(prettyXml, indentLevel);
          }
          textContentExpected = false;

          // Add closing slash
          prettyXml.append("</");
          i += 2; // Skip both '<' and '/'
          continue;
        }

        // Handle new tag
        if (prettyXml.length() > 0 && !insideTag && !textContentExpected) {
          prettyXml.append(System.lineSeparator());
          appendIndent(prettyXml, indentLevel);
        }

        // Add opening tag
        prettyXml.append('<');
        insideTag = true;
        i++;

        // Adjust indent for opening tags (except self-closing)
        if (!isSelfClosing) {
          indentLevel++;
        }
      } else if (currentChar == '>') {
        prettyXml.append('>');
        insideTag = false;
        i++;

        // Check for self-closing tag
        boolean isSelfClosing = (i > 1 && xmlString.charAt(i - 2) == '/');

        // Check next content
        int j = i;
        while (j < length && Character.isWhitespace(xmlString.charAt(j)))
          j++;
        boolean nextIsTag = (j < length && xmlString.charAt(j) == '<');

        textContentExpected = !nextIsTag;

        // Adjust indentation for self-closing tags
        if (isSelfClosing) {
          indentLevel--;
        }

      } else {
        // Handle text content
        if (!insideTag) {
          prettyXml.append(currentChar);
          textContentExpected = true;
          i++;
        } else {
          prettyXml.append(currentChar);
          i++;
        }
      }
    }

    return prettyXml.toString().trim();
  }

  private static void appendIndent(StringBuilder sb, int level) {
    for (int i = 0; i < level * C_Options.localTabSize; i++) {
      sb.append(" ");
    }
  }

  public static String prettifyJson(String text) {
    final char[] chars = text.toCharArray();
    final String newline = System.lineSeparator();

    String ret = "";
    boolean begin_quotes = false;

    for (int i = 0, indent = 0; i < chars.length; i++) {
      char c = chars[i];

      if (c == '\"') {
        ret += c;
        begin_quotes = !begin_quotes;
        continue;
      }

      if (!begin_quotes) {
        switch (c) {
          case '{':
          case '[':
            ret += c + newline + String.format("%" + (indent += C_Options.localTabSize) + "s", "");
            continue;
          case '}':
          case ']':
            ret += newline + ((indent -= C_Options.localTabSize) > 0 ? String.format("%" + indent + "s", "") : "") + c;
            continue;
          case ':':
            ret += c + " ";
            continue;
          case ',':
            ret += c + newline + (indent > 0 ? String.format("%" + indent + "s", "") : "");
            continue;
          default:
            if (Character.isWhitespace(c))
              continue;
        }
      }

      ret += c + (c == '\\' ? "" + chars[++i] : "");
    }

    return ret;
  }

}
