package com.pws.facturas.Commands;

import com.pws.facturas.GlobalDataHolder;
import com.pws.facturas.datatypes.ComlineState;
import com.pws.facturas.datatypes.Factura;
import com.pws.facturas.datatypes.Facturado;
import com.pws.facturas.datatypes.Facturante;
import com.pws.facturas.datatypes.LineaDeFactura;
import com.pws.facturas.utils.Debug;
import com.pws.facturas.utils.Input;
import com.pws.facturas.utils.StringUtils;

public class C_Borra {
  public C_Borra(String com) {
    String[] createParts = StringUtils.breakApart(com);
    // print command help
    if (createParts.length == 1) {
      System.out.print(
      """
      /------------------------------
      | borra factura [nombre identificante factura] -> borra la factura especificada
      | borra facturado [nombre identificante factura] -> borra el facturado especificado
      | borra facturante [nombre identificante factura] -> borra el facturante especificado
      | borra grupo [grupo id] -> borra el grupo especificado
      | borra linea [grupo id] [nombre identificante factura] -> borra la linea especificada
      | borra todo -> borra toda la informacion cargada.
      \\------------------------------
      """);
      ComlineState.success();
      return;
    }

    if (createParts.length >= 2 && createParts.length <= 3) {
      switch (createParts[1].toLowerCase()) {
        case "factura" -> {
          Factura[] facturas = GlobalDataHolder.getFacturas();
          if (createParts.length == 3) {
            Factura f = GlobalDataHolder.dragFactura(createParts[2]);
            if (f == null) {
              Debug.println("//  El nombre especificado no se encontro.");
              ComlineState.fail();
              break;
            }
            facturas = Input.removeObject(facturas, f);
            GlobalDataHolder.setFacturas(facturas);
            ComlineState.success();
          } else {
            Debug.println("//  Ningun nombre especificado.");
            ComlineState.fail();
            break;
          }
        }

        case "facturado" -> {
          Facturado[] facturados = GlobalDataHolder.getFacturados();
          if (createParts.length == 3) {
            Facturado f = GlobalDataHolder.dragFacturado(createParts[2]);
            if (f == null) {
              Debug.println("//  El nombre especificado no se encontro.");
              ComlineState.fail();
              break;
            }
            facturados = Input.removeObject(facturados, f);
            GlobalDataHolder.setFacturados(facturados);
            ComlineState.success();
          } else {
            Debug.println("//  Ningun nombre especificado.");
            ComlineState.fail();
            break;
          }
        }

        case "facturante" -> {
          Facturante[] facturantes = GlobalDataHolder.getFacturantes();
          if (createParts.length == 3) {
            Facturante f = GlobalDataHolder.dragFacturante(createParts[2]);
            if (f == null) {
              Debug.println("//  El nombre especificado no se encontro.");
              ComlineState.fail();
              break;
            }
            facturantes = Input.removeObject(facturantes, f);
            GlobalDataHolder.setFacturantes(facturantes);
            ComlineState.success();
          } else {
            Debug.println("//  Ningun nombre especificado.");
            ComlineState.fail();
            break;
          }
        }

        case "grupo" -> {
          LineaDeFactura[][] grupos = GlobalDataHolder.getGruposDeFacturas();
          if (createParts.length == 3) {
            LineaDeFactura[] g = null;
            try {
              g = GlobalDataHolder.dragGrupo(Integer.parseInt(createParts[2]));
            } catch (NumberFormatException e) {
              /* Not implemented */ }

            if (g == null) {
              Debug.println("//  El id especificado no se encontro.");
              ComlineState.fail();
              break;
            }
            grupos = Input.removeObject(grupos, g);
            GlobalDataHolder.setGruposDeFacturas(grupos);
            ComlineState.success();
          } else {
            Debug.println("//  Ningun nombre especificado.");
            ComlineState.fail();
            break;
          }
        }

        case "liena" -> {
          LineaDeFactura[][] grupos = GlobalDataHolder.getGruposDeFacturas();
          if (createParts.length == 3) {
            LineaDeFactura[] g = null;
            try {
              g = GlobalDataHolder.dragGrupo(Integer.parseInt(createParts[2]));
            } catch (NumberFormatException e) {
              /* Not implemented */ }

            if (g == null) {
              Debug.println("//  El id del grupo especificado no se encontro.");
              ComlineState.fail();
              break;
            }

            LineaDeFactura l = GlobalDataHolder.dragLineaDeGrupo(Integer.parseInt(createParts[2]), createParts[3]);
            if (l == null) {
              Debug.println("//  El nombre especificado no se encontro.");
              ComlineState.fail();
              break;
            }
            g = Input.removeObject(g, l);
            grupos[Integer.parseInt(createParts[2])] = g;
            GlobalDataHolder.setGruposDeFacturas(grupos);
            ComlineState.success();
          } else {
            Debug.println("//  Ningun nombre especificado.");
            ComlineState.fail();
            break;
          }
        }

        default -> {
          if (createParts.length == 2 && createParts[2].toLowerCase().equals("todo")) {
            GlobalDataHolder.opts.resetGlobalData();
            ComlineState.success();
          } else {
            Debug.println("//  El comando es mal formado.");
            ComlineState.fail();
          }
        }
      }
    }

    else {
      Debug.println("//  El comando es mal formado.");
      ComlineState.fail();
      return;
    }
  }
}
