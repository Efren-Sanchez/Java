package com.pws.facturas.datatypes;

public class Facturante {
  private String varName = super.toString();
  private String nombre;
  private String direccion;
  private String CIF;
  private String telefono;
  private String email;

  public Facturante() {
  }

  public Facturante(String nombre, String direccion, String CIF, String telefono, String email) {
    this.nombre = nombre;
    this.direccion = direccion;
    this.CIF = CIF;
    this.telefono = telefono;
    this.email = email;
  }

  
  public Facturante(Facturante original) {
    this.nombre = original.nombre;
    this.direccion = original.direccion;
    this.CIF = original.CIF;
    this.telefono = original.telefono;
    this.email = original.email;
  }

  @Override
  public final String toString() {
    return "<facturante>" +
        "<varName>" + varName + "</varName>" +
        "<nombre>" + nombre + "</nombre>" +
        "<direccion>" + direccion + "</direccion>" +
        "<cif>" + CIF + "</cif>" +
        "<telefono>" + telefono + "</telefono>" +
        "<email>" + email + "</email>" +
        "</facturante>";
  }

  public String toSimpleString() {
    return
    "\"varname\": \"" + varName + "\"," +
    "\"nombre\": \"" + nombre + "\", "+
    "\"direccion\": \"" + direccion + "\", "+
    "\"cif\": \"" + CIF + "\", "+
    "\"telefono\": \"" + telefono + "\", "+
    "\"email\": \"" + email + "\"";
  }

  public String getCIF() {
    return CIF;
  }

  public String getDireccion() {
    return direccion;
  }

  public String getEmail() {
    return email;
  }

  public String getNombre() {
    return nombre;
  }

  public String getTelefono() {
    return telefono;
  }

  public String getVarName() {
    return varName;
  }

  public void setCIF(String cIF) {
    CIF = cIF;
  }

  public void setDireccion(String direccion) {
    this.direccion = direccion;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public void setTelefono(String telefono) {
    this.telefono = telefono;
  }

  public void setVarName(String varName) {
    this.varName = varName;
  }
}