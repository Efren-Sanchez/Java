package com.pws.facturas;

import java.util.Arrays;

import com.pws.facturas.Commands.C_Options;
import com.pws.facturas.datatypes.Factura;
import com.pws.facturas.datatypes.Facturado;
import com.pws.facturas.datatypes.Facturante;
import com.pws.facturas.datatypes.LineaDeFactura;
import com.pws.facturas.utils.Debug;
import com.pws.facturas.utils.StringUtils;

public class GlobalDataHolder {
  private static Factura[] facturas = new Factura[0];
  private static Facturado[] facturados = new Facturado[0];
  private static Facturante[] facturantes = new Facturante[0];
  private static LineaDeFactura[][] gruposDeFacturas = new LineaDeFactura[0][0];
  public static C_Options opts;

  public static void putIntoFacturas(Factura factura) {
    facturas = Arrays.copyOf(facturas, facturas.length + 1);
    facturas[facturas.length - 1] = factura;
  }

  public static void putIntoFacturados(Facturado facturado) {
    facturados = Arrays.copyOf(facturados, facturantes.length + 1);
    facturados[facturados.length - 1] = facturado;
  }

  public static void putIntoFacturantes(Facturante facturante) {
    facturantes = Arrays.copyOf(facturantes, facturantes.length + 1);
    facturantes[facturantes.length - 1] = facturante;
  }

  public static int putNewGroup() {
    gruposDeFacturas = Arrays.copyOf(gruposDeFacturas, gruposDeFacturas.length + 1);
    gruposDeFacturas[gruposDeFacturas.length - 1] = new LineaDeFactura[0];
    return gruposDeFacturas.length - 1;
  }

  public static void putIntoGruposLinea(int index, LineaDeFactura lineaDeFacturas) {
    gruposDeFacturas[index] = Arrays.copyOf(gruposDeFacturas[index], gruposDeFacturas[index].length + 1);
    gruposDeFacturas[index][gruposDeFacturas[index].length - 1] = lineaDeFacturas;
  }

  public static Factura dragFactura(String varName) {
    Factura f = null;
    for (Factura fac : facturas) {
      if (fac.getVarName().equals(varName)) {
        f = fac;
        break;
      }
    }
    return f;
  }

  public static Facturado dragFacturado(String varName) {
    Facturado f = null;
    for (Facturado fac : facturados) {
      if (fac.getVarName().equals(varName)) {
        f = fac;
        break;
      }
    }
    return f;
  }

  public static Facturante dragFacturante(String varName) {
    Facturante f = null;
    for (Facturante fac : facturantes) {
      if (fac.getVarName().equals(varName)) {
        f = fac;
        break;
      }
    }
    return f;
  }

  public static LineaDeFactura[] dragGrupo(int grupoId) {
    return gruposDeFacturas[grupoId];
  }

  public static LineaDeFactura dragLinea(String varName) {
    LineaDeFactura l = null;
    for (int i = 0; i < gruposDeFacturas.length; i++) {
      int line = getIndexOfLinea(i, varName);
      if (line >= 0)
        l = gruposDeFacturas[i][line];
    }
    return l;
  }

  public static LineaDeFactura dragLineaDeGrupo(int grupoId, String varName) {
    LineaDeFactura l = null;
    int line = getIndexOfLinea(grupoId, varName);
    if (line >= 0)
      l = gruposDeFacturas[grupoId][line];
    return l;
  }

  public static int getIndexOfLinea(int grupoId, String varName) {
    for (int i = 0; i < gruposDeFacturas[grupoId].length; i++) {
      if (gruposDeFacturas[grupoId][i].getVarName().equals(varName)) {
        return i;
      }
    }

    return -1;
  }

  public static void setFacturas(Factura[] facturas) {
    GlobalDataHolder.facturas = facturas;
  }

  public static void setFacturados(Facturado[] facturados) {
    GlobalDataHolder.facturados = facturados;
  }

  public static void setFacturantes(Facturante[] facturantes) {
    GlobalDataHolder.facturantes = facturantes;
  }

  public static void setGruposDeFacturas(LineaDeFactura[][] gruposDeFacturas) {
    GlobalDataHolder.gruposDeFacturas = gruposDeFacturas;
  }

  public static void setGrupo(int grupoID, LineaDeFactura[] grupo) {
    GlobalDataHolder.gruposDeFacturas[grupoID] = grupo;
  }

  public static Facturado[] getFacturados() {
    return facturados;
  }

  public static Facturante[] getFacturantes() {
    return facturantes;
  }

  public static Factura[] getFacturas() {
    return facturas;
  }

  public static LineaDeFactura[][] getGruposDeFacturas() {
    return gruposDeFacturas;
  }

  public static String staticToString() {
    Debug.println("/------------------------------\n");
    StringBuilder sb = new StringBuilder("<GlobalData>");
    sb.append("<facturas>").append(Arrays.toString(facturas).replace(", ", "")).append("</facturas>");
    sb.append("<facturados>").append(Arrays.toString(facturados).replace(", ", "")).append("</facturados>");
    sb.append("<facturantes>").append(Arrays.toString(facturantes).replace(", ", "")).append("</facturantes>");
    sb.append("<gruposDeFacturas>");
    int id = 0;
    for (LineaDeFactura[] grupo : gruposDeFacturas) {
      sb.append("<groupID id='" + id + "'>");
      for (LineaDeFactura linea : grupo) {
        sb.append(linea.toString());
      }
      sb.append("</groupID>");
      id++;
    }
    sb.append("</gruposDeFacturas></GlobalData>");
    return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
        StringUtils.prettifyXml(sb.toString().replaceAll("\\[", "").replaceAll("\\]", ""))
        + "\n\n\\------------------------------\n";
    
  }

  public static String staticToSimpleString() {
    Debug.println("/------------------------------\n");
    StringBuilder sb = new StringBuilder("{\"GlobalData\": {");
    sb.append("\"facturas\": {");
    for (Factura factura : facturas) {
      sb.append(factura.toSimpleString());
    }
    sb.append(", ");
    sb.append("\"facturados\": {");
    for (Facturado facturado : facturados) {
      sb.append(facturado.toSimpleString());
    }
    sb.append("}, ");
    sb.append("\"facturantes\": {");
    for (Facturante facturante : facturantes) {
      sb.append(facturante.toSimpleString());
    }
    sb.append("}, ");
    sb.append("\"gruposDeFacturas\": {");
    for (int j = 0; j < gruposDeFacturas.length; j++) {
      sb.append("\"groupID\": " + j + ", \"lineas\": [");
      for (int i = 0; i < gruposDeFacturas[j].length; i++) {
        sb.append(gruposDeFacturas[j][i].toSimpleString());
        if (i != gruposDeFacturas[j].length - 1)
          sb.append(",");
      }
      sb.append("]");
    }
    sb.append("}}}}\n");
    return StringUtils.prettifyJson(sb.toString()) + "\n\n\\------------------------------\n";
  }
}