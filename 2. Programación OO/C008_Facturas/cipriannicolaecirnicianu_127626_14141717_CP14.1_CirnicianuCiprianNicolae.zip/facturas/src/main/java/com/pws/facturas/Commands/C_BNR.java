package com.pws.facturas.Commands;

import java.io.File;
import java.time.LocalDateTime;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.pws.facturas.GlobalDataHolder;
import com.pws.facturas.datatypes.ComlineState;
import com.pws.facturas.datatypes.Factura;
import com.pws.facturas.datatypes.FileManager;
import com.pws.facturas.datatypes.IVA;
import com.pws.facturas.datatypes.LineaDeFactura;
import com.pws.facturas.datatypes.PFloat;
import com.pws.facturas.utils.Debug;
import com.pws.facturas.utils.StringUtils;

public class C_BNR {
  public static void saveBnr(String com) {
    String[] bnrParts = StringUtils.breakApart(com);

    if (bnrParts.length == 1) {
      System.out.print(
      """
      /------------------------------
      | saveBnr -> guarda una factura en "/data/bnr/[identificador].json"
      | loadBnr -> carga los datos de una factura.
      \\------------------------------
      """);
      ComlineState.fail();
      return;
    } else if (bnrParts.length == 2) {
      StringBuilder bnr = new StringBuilder("{" + GlobalDataHolder.dragFactura(bnrParts[1]).toSimpleString());
      String completeBnr = StringUtils.prettifyJson(bnr.append("}").toString());
      File bnrFile = FileManager.createFile("/data/bnr/" + bnrParts[1] + ".json");
      FileManager.updateFile(bnrFile, completeBnr, false, false);
      Debug.println("//  Fichero " + bnrFile.getAbsolutePath() + " se creo con exito.");
      ComlineState.success();
    } else {
      Debug.print("// Mal formatedo del comando.");
      ComlineState.fail();
    }
  }

  public static void loadBnr(String com) {
    String[] bnrParts = StringUtils.breakApart(com);

    if (bnrParts.length == 1) {
      System.out.print(
      """
      /------------------------------
      | saveBnr -> guarda una factura en "/data/bnr/[identificador].json"
      | loadBnr -> carga los datos de una factura.
      \\------------------------------
      """);
      ComlineState.fail();
      return;
    } else if (bnrParts.length == 2) {
      File bnrFile = FileManager.getFile("/data/bnr/" + bnrParts[1] + ".json");
      if (bnrFile == null) {
        Debug.print("File " + bnrParts[1] + ".json not found.");
        ComlineState.fail();
        return;
      }

      JsonElement jsonData = FileManager.loadJson(bnrFile.getAbsolutePath());
      JsonObject jFactura = jsonData.getAsJsonObject().get("factura").getAsJsonObject();
      JsonObject jFacturado = jFactura.get("facturado").getAsJsonObject();
      JsonObject jfactuante = jFactura.get("facturante").getAsJsonObject();
      JsonArray jLineas = jFactura.get("lineas").getAsJsonArray();

      Factura factura = new Factura();
      factura.setVarName(jFactura.get("varname").getAsString());
      factura.getFacurante().setVarName(jfactuante.get("varname").getAsString());
      factura.getFacurante().setNombre(jfactuante.get("nombre").getAsString());
      factura.getFacurante().setDireccion(jfactuante.get("direccion").getAsString());
      factura.getFacurante().setCIF(jfactuante.get("cif").getAsString());
      factura.getFacurante().setEmail(jfactuante.get("email").getAsString());

      factura.getFacturado().setVarName(jFacturado.get("varname").getAsString());
      factura.getFacturado().setNombre(jFacturado.get("nombre").getAsString());
      factura.getFacturado().setNifOCif(jFacturado.get("nifocif").getAsString());

      factura.setFechaYHora(LocalDateTime.parse(jFactura.get("fechayhora").getAsString()));
      factura.setNumeroFactura(Integer.parseUnsignedInt(jFactura.get("numeroFactura").getAsString()));

      LineaDeFactura[] lineas = new LineaDeFactura[jLineas.size()];
      for (int i = 0; i < lineas.length; i++) {
        JsonObject jLine = jLineas.get(i).getAsJsonObject();
        lineas[i] = new LineaDeFactura();
        lineas[i].setVarName(jLine.get("varname").getAsString());
        lineas[i].setArticulo(jLine.get("articulo").getAsString());
        try {lineas[i].setCantidad(Integer.parseUnsignedInt(jLine.get("cantidad").getAsString()));}
        catch (NumberFormatException e) {
          Debug.println(ComlineState.FAIL.getPrint() + " La cantidad no es un numero entero valido.");
          return;
        }
        try { lineas[i].setPrecio(new PFloat(jLine.get("precio").getAsString()));}
        catch (NumberFormatException e) {
          Debug.println(ComlineState.FAIL.getPrint() + " El precio no es un numero flotante valido.");
          return;
        }
        lineas[i].setIva(IVA.get(jLine.get("iva").getAsString()));
      }

      factura.setLineasFactura(lineas);
      factura.setTotalFactura(new PFloat(jFactura.get("totalfactura").getAsString()));

      GlobalDataHolder.putIntoFacturas(factura);
      GlobalDataHolder.putIntoFacturados(factura.getFacturado());
      GlobalDataHolder.putIntoFacturantes(factura.getFacurante());
      int group = GlobalDataHolder.putNewGroup();
      for (LineaDeFactura lineaDeFactura : factura.getLineasFactura()) {
        GlobalDataHolder.putIntoGruposLinea(group, lineaDeFactura);
      }

      Debug.println("//  Fichero " + bnrFile.getAbsolutePath() + " se cargo con exito.");
      ComlineState.success();
    } else {
      Debug.print("// Mal formatedo del comando.");
      ComlineState.fail();
    }
  }
}