package com.pws.facturas.Commands;

import java.time.LocalDateTime;

import com.pws.facturas.GlobalDataHolder;
import com.pws.facturas.datatypes.ComlineState;
import com.pws.facturas.datatypes.Factura;
import com.pws.facturas.datatypes.Facturado;
import com.pws.facturas.datatypes.Facturante;
import com.pws.facturas.datatypes.IVA;
import com.pws.facturas.datatypes.LineaDeFactura;
import com.pws.facturas.datatypes.PFloat;
import com.pws.facturas.utils.Debug;
import com.pws.facturas.utils.Factory;
import com.pws.facturas.utils.StringUtils;

public class C_Create {
  public C_Create(String com) {
    String[] createParts = StringUtils.breakApart(com);

    // print command help
    if (createParts.length == 1) {
      System.out.print(
      """
      /------------------------------
      | crea factura factory -> crea una factura paso por paso.
      | crea factura create factura [nombre identificante factura] [nombre identificante factuante] [nombre identificante facturado] [group id]
      |     \\> crea una factura directamente. necesita crear un facturante, facturado, un grupo, y anadir lineas al grupo.
      |
      | crea facturado factory -> crea un facturado paso por paso.
      | crea facturado [nombre identificador facturado] [nombre] [NIF o CIF]
      |     \\> crea una factura directamente.
      |
      | crea facturante factory -> crea un facturante paso por paso;
      | crea facturante [nombre identificador linea] [nombre] [direccion] [CIF] [telefono] [email]
      |     \\> crea una factura directamente.
      |
      | crea grupo -> crea un grupo de lineas de factura vacio. acuerdate el id del grupo.
      |
      | crea linea factory -> crea una linea. no es necesario crear un grupo anteriormente.
      | crea linea [nombre identificador linea] [grupo id] [nombre articulo] [cantidad] [precio] [nombre IVA (NORMAL, REDUCIDO, SUPERREDUCIDO)]
      |     \\> crea una linea directamente. necesita crear un grupo anteriormente.
      \\------------------------------
      """);
      ComlineState.fail();
      return;
    }

    // select and run create command
    switch (createParts[1]) {
      case "factura" -> {
        if (createParts.length == 3 && createParts[2].equals("factory")) {
          Factura f = Factory.makeFactura();
          GlobalDataHolder.putIntoFacturas(f);
          Debug.println("\\ La facrtura se creo con exito.");
        } else {
          Factura f = bulkFactura(createParts);
          GlobalDataHolder.putIntoFacturas(f);
        }

        ComlineState.success();
      }

      case "facturado" -> {
        if (createParts.length == 3 && createParts[2].equals("factory")) {
          Facturado f = Factory.makeFacturado(true);
          GlobalDataHolder.putIntoFacturados(f);
          Debug.println("\\ El facrturado se creo con exito.");
        } else {
          Facturado f = bulkFacturado(createParts);
          GlobalDataHolder.putIntoFacturados(f);
        }
        ComlineState.success();
      }

      case "facturante" -> {
        if (createParts.length == 3 && createParts[2].equals("factory")) {
          Facturante f = Factory.makeFacturante(true);
          GlobalDataHolder.putIntoFacturantes(f);
          Debug.println("\\ El facrturante se creo con exito.");
        } else {
          Facturante f = bulkFacturante(createParts);
          GlobalDataHolder.putIntoFacturantes(f);
        }
        ComlineState.success();
      }

      case "grupo" -> {
        int id = GlobalDataHolder.putNewGroup();
        Debug.println("Grupo ha sido creado con id: " + id);
        ComlineState.success();
      }

      case "linea" -> {
        if (createParts.length == 3 && createParts[2].equals("factory")) {
          LineaDeFactura l = Factory.makeLine(true, true);
          Debug.println("| un grupo es necesario.");
          int grupoId = Factory.makeGroup(false);
          Debug.println("\\ La linea se creo con exito.");
          GlobalDataHolder.putIntoGruposLinea(grupoId, l);
        } else {
          LineaDeFactura l = bulkLinea(createParts);
          GlobalDataHolder.putIntoGruposLinea(Integer.parseInt(createParts[3]), l);
        }

        ComlineState.success();
      }

      default -> {
        Debug.println("//  El comando '" + com + "' no existe. Intenta \"create\" sin argumentos para una lista de comandos validos.");
        ComlineState.fail();
      }
    }
  }

  public static final Factura bulkFactura(String[] createParts) {
    if (createParts.length != 6) {
      Debug.println("//  El comando puede ser mas corto o mas largo de lo necesitado. Los parametros buscados son: \n" +
      "\\ crea factura [nombre identificante factura] [nombre identificante factuante] [nombre identificante facturado] [group id]");
      ComlineState.fail();
      return null;
    } else {
      Facturante fe = GlobalDataHolder.dragFacturante(createParts[3]);
      Facturado fc = GlobalDataHolder.dragFacturado(createParts[4]);
      LocalDateTime time = LocalDateTime.now();
      int numeroFactura = GlobalDataHolder.getFacturas().length + 1;
      LineaDeFactura[] grupo = GlobalDataHolder.dragGrupo(Integer.parseInt(createParts[5]));
      PFloat total = Factura.calculateTotal(GlobalDataHolder.dragGrupo(Integer.parseInt(createParts[5])));

      boolean broke = false;
      if (fe == null) {
        Debug.print("// 3. Facturante no se encontro.");
        broke = true;
      } else if (fc == null) {
        Debug.print("// 4. Facturado no se encontro.");
        broke = true;
      } else if (numeroFactura == -1) {
        Debug.print("// 5. El grupo no se encontro.");
        broke = true;
      }
      if (broke) {
        return null;
      }

      Factura f = new Factura(fe, fc, time, numeroFactura, grupo, total);
      f.setVarName(createParts[2]);
      Debug.println("//  Factura " + f.getVarName() + " se ha annadido con exito: " + f.toSimpleString());
      return f;
    }
  }

  public static final Facturado bulkFacturado(String[] createParts) {
    if (createParts.length != 5) {
      Debug.println("//  El comando puede ser mas corto o mas largo de lo necesitado. Los parametros buscados son: \n" +
      "\\ crea facturado [nombre identificador facturado] [nombre] [NIF o CIF]");
      ComlineState.fail();
      return null;
    } else {
      Facturado f = new Facturado(createParts[3], createParts[4]);
      f.setVarName(createParts[2]);
      Debug.println("//  Facturado " + f.getVarName() + " se ha annadido con exito: " + f.toSimpleString());
      return f;
    }
  }

  public static final Facturante bulkFacturante(String[] createParts) {
    if (createParts.length != 8) {
      Debug.println("//  El comando puede ser mas corto o mas largo de lo necesitado. Los parametros buscados son: \n" +
      "\\ crea facturante [nombre identificador linea] [nombre] [direccion] [CIF] [telefono] [email]");
      ComlineState.fail();
      return null;
    } else {
      Facturante f = new Facturante(createParts[3], createParts[4], createParts[5], createParts[6], createParts[7]);
      f.setVarName(createParts[2]);
      Debug.println("//  Facturante " + f.getVarName() + " se ha annadido con exito: " + f.toSimpleString());
      return f;
    }
  }

  public static final LineaDeFactura bulkLinea(String[] createParts) {
    if (createParts.length != 8) {
      Debug.println("//  El comando puede ser mas corto o mas largo de lo necesitado. Los parametros buscados son: \n" +
      "\\ crea linea [nombre identificador linea] [grupo id] [nombre articulo] [cantidad] [precio] [nombre IVA (NORMAL, REDUCIDO, SUPERREDUCIDO)]");
      ComlineState.fail();
      return null;
    } else {
      LineaDeFactura l = null;
      try {l = new LineaDeFactura(createParts[4], Integer.parseInt(createParts[5]), new PFloat(createParts[6]), IVA.get(createParts[7]));}
      catch (NumberFormatException e) {
        Debug.println(ComlineState.FAIL.getPrint() + " El precio o la cantidad no es un numero valido.");
        return null;
      }
      l.setVarName(createParts[2]);
      Debug.println("//  Linea de factura " + l.getVarName() + " se ha annadido con exito: " + l.toSimpleString());
      return l;
    }
  }
}
