package com.pws.facturas.Commands;

import com.pws.facturas.GlobalDataHolder;
import com.pws.facturas.datatypes.ComlineState;
import com.pws.facturas.datatypes.Factura;
import com.pws.facturas.datatypes.Facturado;
import com.pws.facturas.datatypes.Facturante;
import com.pws.facturas.datatypes.LineaDeFactura;
import com.pws.facturas.utils.Debug;
import com.pws.facturas.utils.Factory;
import com.pws.facturas.utils.Input;
import com.pws.facturas.utils.StringUtils;

public class C_Modifica {
  // try getting the list of elements, modifying what needs to be modified and
  // replacing the old one with the new one.
  public C_Modifica(String com) {
    String[] createParts = StringUtils.breakApart(com);

    // print command help
    if (createParts.length == 1) {
      System.out.print(
      """
      /------------------------------
      | modifica factura [nombre identificante factura] [FACTORY o complete] -> modifica la factura especificada
      | modifica facturado [nombre identificante factura] [FACTORY o complete] -> modifica el facturado especificado
      | modifica facturante [nombre identificante factura] [FACTORY o complete] -> modifica el facturante especificado
      | modifica linea [grupo id] [nombre identificante factura] [FACTORY o complete]-> modifica la linea especificada
      |
      | Para ver como se hace la varsion completa, escribe create, seguido del elemento que quieres modificar, y nada mas.
      | Especificar, que en lugar de poner "complete" pones los arguments despues del nombre identificativo.
      | Ejemplo: modificar facturado id_PEEPE Pepe 11223344
      \\------------------------------
      """);
      ComlineState.success();
      return;
    }

    if (createParts.length >= 2 && createParts.length <= 3) {
      switch (createParts[1].toLowerCase()) {
        case "factura" -> {
          
          if (createParts.length == 4) {
            Factura f = null;
            if (createParts[3].toLowerCase().equals("factory"))
              f = Factory.makeFactura();
            else
              f = C_Create.bulkFactura(createParts);
            
            if (f == null) {
              Debug.println("//  La factura no se pudo modificar.");
              ComlineState.fail();
              break;
            }

            Factura[] facturas = GlobalDataHolder.getFacturas();
            Factura removed = GlobalDataHolder.dragFactura(createParts[2]);
            facturas = Input.removeObject(facturas, removed);
            GlobalDataHolder.setFacturas(facturas);
            GlobalDataHolder.putIntoFacturas(f);

            ComlineState.success();
          } else {
            Debug.println("//  Ningun nombre especificado.");
            ComlineState.fail();
            break;
          }
        }

        case "facturado" -> {
          
          if (createParts.length == 3) {
            Facturado f = null;
            if(createParts[3].toLowerCase().equals("factory"))
              f = Factory.makeFacturado(true);
            else
              f = C_Create.bulkFacturado(createParts);
            
            if (f == null) {
              Debug.println("//  El facturado no se pudo modificar.");
              ComlineState.fail();
              break;
            }
            Facturado[] facturados = GlobalDataHolder.getFacturados();
            Facturado removed =  GlobalDataHolder.dragFacturado(createParts[2]);
            facturados = Input.removeObject(facturados, removed);
            GlobalDataHolder.setFacturados(facturados);
            GlobalDataHolder.putIntoFacturados(f);

            ComlineState.success();
          } else {
            Debug.println("//  Ningun nombre especificado.");
            ComlineState.fail();
            break;
          }
        }

        case "facturante" -> {
          
          if (createParts.length == 3) {
            Facturante f = null;
            if(createParts[3].toLowerCase().equals("factory"))
              f = Factory.makeFacturante(true);
            else
              f = C_Create.bulkFacturante(createParts);
            if (f == null) {
              Debug.println("//  El nombre especificado no se encontro.");
              ComlineState.fail();
              break;
            }

            Facturante[] facturantes = GlobalDataHolder.getFacturantes();
            Facturante removed = GlobalDataHolder.dragFacturante(createParts[2]);
            facturantes = Input.removeObject(facturantes, removed);
            GlobalDataHolder.setFacturantes(facturantes);
            GlobalDataHolder.putIntoFacturantes(f);

            ComlineState.success();
          } else {
            Debug.println("//  Ningun nombre especificado.");
            ComlineState.fail();
            break;
          }
        }

        case "liena" -> {
          
          if (createParts.length == 3) {
            LineaDeFactura[] g = null;
            try {
              g = GlobalDataHolder.dragGrupo(Integer.parseInt(createParts[2]));
            } catch (NumberFormatException e) {
              /* Not implemented */ 
            }

            if (g == null) {
              Debug.println("//  El id del grupo especificado no se encontro.");
              ComlineState.fail();
              break;
            }

            LineaDeFactura l = null;
            if(createParts[3].toLowerCase().equals("factory"))
              l = Factory.makeLine(true, false);
            else
              l = C_Create.bulkLinea(createParts);

            if (l == null) {
              Debug.println("//  El nombre especificado no se encontro.");
              ComlineState.fail();
              break;
            }

            LineaDeFactura[][] grupos = GlobalDataHolder.getGruposDeFacturas();
            g = Input.removeObject(g, l);
            grupos[Integer.parseInt(createParts[2])] = g;
            GlobalDataHolder.setGruposDeFacturas(grupos);

            ComlineState.success();
          } else {
            Debug.println("//  Ningun nombre especificado.");
            ComlineState.fail();
            break;
          }
        }

        default -> {
          Debug.println("//  El comando es mal formado.");
          ComlineState.fail();
        }
      }
    }

    else {
      Debug.println("//  El comando es mal formado.");
      ComlineState.fail();
      return;
    }
  }
}
