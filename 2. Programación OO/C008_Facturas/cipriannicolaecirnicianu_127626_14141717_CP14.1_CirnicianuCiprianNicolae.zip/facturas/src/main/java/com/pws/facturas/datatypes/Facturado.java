package com.pws.facturas.datatypes;

public class Facturado {
  private String varName = super.toString();
  private String nombre = null;
  private String NifOCif = null;

  public Facturado() {
  }

  public Facturado(String nombre, String NifOCif) {
    this.nombre = nombre;
    this.NifOCif = NifOCif;
  }

  public Facturado(Facturado original) {
    this.nombre = original.nombre;
    this.NifOCif = original.NifOCif;
    this.varName = original.varName;
  }

  @Override
  public final String toString() {
    return "<facturado>" +
        "<varName>" + varName + "</varName>" +
        "<nombre>" + nombre + "</nombre>" +
        "<nifocif>" + NifOCif + "</nifocif>" +
        "</facturado>";
  }

  public String toSimpleString() {
    return
    "\"varname\": \"" + varName + "\"," +
    "\"nombre\": \"" + nombre + "\", " +
    "\"nifocif\": \"" + NifOCif + "\"";
  }

  public String getNifOCif() {
    return NifOCif;
  }

  public String getNombre() {
    return nombre;
  }
  
  public String getVarName() {
    return varName;
  }

  public void setNifOCif(String nifOCif) {
    NifOCif = nifOCif;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }
  
  public void setVarName(String varName) {
    this.varName = varName;
  }
}