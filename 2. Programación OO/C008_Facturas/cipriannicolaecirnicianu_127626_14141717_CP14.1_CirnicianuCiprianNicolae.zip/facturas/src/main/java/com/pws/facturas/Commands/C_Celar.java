package com.pws.facturas.Commands;

import java.io.IOException;

import com.pws.facturas.datatypes.ComlineState;
import com.pws.facturas.utils.Debug;

public class C_Celar {
  
  public C_Celar() {
    try {
      String os = System.getProperty("os.name").toLowerCase();

      if (os.contains("win")) {
        // For Windows
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
      } else {
        // For Unix-like systems
        new ProcessBuilder("clear").inheritIO().start().waitFor();
      }
      ComlineState.success();
    } catch (IOException | InterruptedException e) {
      Debug.logError(e);
      ComlineState.fail();
    }
  }
}
