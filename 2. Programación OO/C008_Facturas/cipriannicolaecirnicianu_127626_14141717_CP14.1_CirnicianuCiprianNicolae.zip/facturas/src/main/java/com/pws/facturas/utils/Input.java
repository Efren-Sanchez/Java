package com.pws.facturas.utils;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.jline.reader.Candidate;
import org.jline.reader.Completer;
import org.jline.reader.LineReader;
import org.jline.reader.LineReaderBuilder;
import org.jline.reader.ParsedLine;
import org.jline.reader.impl.history.DefaultHistory;
import org.jline.terminal.TerminalBuilder;

import com.pws.facturas.Commands.C_Options;

public class Input {
  private static Logger jLineLogger = Logger.getLogger("org.jline");
  private static Logger rootLogger = Logger.getLogger("");
  private static Path historyFile = Paths.get("data/system/.historial");

  // enable logging by setting this to Level.FINEST or Level.OFF to disable
  private static final Level state = Level.OFF;

  public static LineReader reader;

  public static void create() {
    rootLogger.setLevel(state);
    jLineLogger.setLevel(state);
    rootLogger.getHandlers()[0].setLevel(state);

    try {
      reader = LineReaderBuilder.builder()
          .terminal(TerminalBuilder.builder()
              .system(true)
              .build())
          .completer(new Completer() {

            @Override
            public void complete(LineReader reader, ParsedLine line, List<Candidate> candidates) {
              candidates.add(new Candidate("xml"));
              candidates.add(new Candidate("bnr"));
              candidates.add(new Candidate("grupo"));
              candidates.add(new Candidate("linea"));
              candidates.add(new Candidate("exit"));
              candidates.add(new Candidate("help"));
              candidates.add(new Candidate("clear"));
              candidates.add(new Candidate("gdata"));
              candidates.add(new Candidate("options"));
              candidates.add(new Candidate("floatingPrecision"));
              candidates.add(new Candidate("reload"));
              candidates.add(new Candidate("crea"));
              candidates.add(new Candidate("borra"));
              candidates.add(new Candidate("todo"));
              candidates.add(new Candidate("modifica"));
              candidates.add(new Candidate("print"));
              candidates.add(new Candidate("defaultLaunchFile"));
              candidates.add(new Candidate("defaultTabSize"));
              candidates.add(new Candidate("enableAutoClear"));
              candidates.add(new Candidate("enableAutoExit"));
              candidates.add(new Candidate("factura"));
              candidates.add(new Candidate("facturado"));
              candidates.add(new Candidate("facturante"));
              candidates.add(new Candidate("factory"));
            }
          })
          .variable(LineReader.SECONDARY_PROMPT_PATTERN, "> ")
          .history(new DefaultHistory())
          .variable(LineReader.HISTORY_FILE, historyFile)
          .variable(LineReader.HISTORY_SIZE, 1000)
          .build();
    } catch (IOException e) {
      Debug.logError(e);
    }
  }

  public static String read() {
    return reader.readLine(C_Options.comlineState.getPrint()).replaceAll("`\n", "\n");
  }

  public static <T> T[] removeObject(T[] array, T other) {
    T[] newArray = null;
    int index = 0;

    for (T element : array) {
      if (!element.equals(other)) {
        if (index == 0)
          newArray = Arrays.copyOf(array, 0);

        newArray = Arrays.copyOf(newArray, index + 1);
        newArray[index] = element;
      }
    }

    return newArray;
  }
}
