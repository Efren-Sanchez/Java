package com.pws.facturas.datatypes;

public class LineaDeFactura {
  private String varName = super.toString();
  private String articulo = "";
  private int cantidad = 0;
  private PFloat precio = new PFloat(); 
  private IVA iva = IVA.NORMAL;

  public LineaDeFactura() {
  }

  public LineaDeFactura(String articulo, int cantidad, PFloat precio, IVA iva) {
    this.articulo = articulo;
    this.cantidad = cantidad;
    this.precio = precio;
    this.iva = iva;
  }

  public LineaDeFactura(LineaDeFactura original) {
    this.articulo = original.articulo;
    this.cantidad = original.cantidad;
    this.precio = original.precio;
    this.iva = original.iva;
  }

  public PFloat total() {
    PFloat multiplied = PFloat.multiply(precio, new PFloat(cantidad, 0));
    return multiplied.divide(new PFloat(0, iva.getPercentage()));
  }

  @Override
  public final String toString() {
    return "<lineaDeFactura>" +
        "<varName>" + varName + "</varName>" +
        "<articulo>" + articulo + "</articulo>" +
        "<cantidad>" + cantidad + "</cantidad>" +
        "<precio>" + precio.toString() + "</precio>" +
        "<iva>" + iva.getPercentage() + "</iva>" +
        "</lineaDeFactura>";
  }

  public String toSimpleString() {
    return "{" +
    "\"varname\": \"" + varName + "\","+
    "\"articulo\": \"" + articulo + "\", "+
    "\"cantidad\": \"" + cantidad + "\", "+
    "\"precio\": \"" + precio.toString() + "\", "+
    "\"iva\": \"" + iva.toString() + "\""+
    "}";
  }

  public String getArticulo() {
    return articulo;
  }

  public int getCantidad() {
    return cantidad;
  }

  public IVA getIva() {
    return iva;
  }

  public PFloat getPrecio() {
    return precio;
  }

  public String getVarName() {
    return varName;
  }

  public void setArticulo(String articulo) {
    this.articulo = articulo;
  }

  public void setCantidad(int cantidad) {
    this.cantidad = cantidad;
  }

  public void setIva(IVA iva) {
    this.iva = iva;
  }

  public void setPrecio(PFloat precio) {
    this.precio = precio;
  }

  public void setVarName(String varName) {
    this.varName = varName;
  }
}
