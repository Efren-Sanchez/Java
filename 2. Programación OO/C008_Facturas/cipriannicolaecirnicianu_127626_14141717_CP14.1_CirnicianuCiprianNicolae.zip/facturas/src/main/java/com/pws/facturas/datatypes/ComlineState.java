package com.pws.facturas.datatypes;

import com.pws.facturas.Commands.C_Options;

public enum ComlineState {
  SUCCESS("[]> "),
  FAIL("[X]> "),
  TRACTOR("]> ");

  private String print = "";
  private ComlineState(String printer) {
    this.print = printer;
  }

  public String getPrint() {
    return print;
  }

  @Override
  public String toString() {
    if(this.equals(SUCCESS)) return "SUCCESS";
    else if(this.equals(FAIL)) return "FAIL";

    return "SUCCESS";
  }

  public static void success() {
    C_Options.comlineState = SUCCESS;
  }

  public static void fail() {
    C_Options.comlineState = FAIL;
  }

  public static void tractor() {
    C_Options.comlineState = TRACTOR;
  }
}
