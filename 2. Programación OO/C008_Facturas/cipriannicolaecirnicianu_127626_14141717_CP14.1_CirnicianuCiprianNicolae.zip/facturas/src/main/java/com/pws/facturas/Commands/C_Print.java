package com.pws.facturas.Commands;

import java.util.Arrays;

import com.pws.facturas.GlobalDataHolder;
import com.pws.facturas.datatypes.ComlineState;
import com.pws.facturas.datatypes.Facturante;
import com.pws.facturas.datatypes.LineaDeFactura;
import com.pws.facturas.utils.Debug;
import com.pws.facturas.utils.StringUtils;

public class C_Print {
  public C_Print(String com) {
    String[] printParts = StringUtils.breakApart(com);

    if (printParts.length == 1) {
      Debug.print(
      """
      /------------------------------
      | print factura [nombre identificador factura] [XML o BNR] -> muestra una factura en formato xml o json.
      | print facturado [nombre identificador facturado] [XML o BNR] -> muestra un facturado en facturado xml o json.
      | print facturante [nombre identificador facturante] [XML o BNR] -> muestra un facturante en formato xml o json.
      |
      | print grupo [grupo id] [XML o BNR] -> muestra un grupo en formato xml o json.
      | print linea [nombre identificador facturante] [grupo id]  [XML o BNR] -> muestra una linea en formato xml o json.
      \\------------------------------
      """);
      ComlineState.fail();
      return;
    }

    String out = "";

    switch (printParts[1]) {
      case "factura" -> {
        if (GlobalDataHolder.dragFactura(printParts[2]) == null) {
          out = "// The object " + printParts[2] + " does not exist.";
          ComlineState.fail();
          break;
        }
        if (printParts.length == 3) {
          out = StringUtils.prettifyXml(GlobalDataHolder.dragFactura(printParts[2]).toString());
          ComlineState.success();
          break;
        }
        if (printParts.length != 4) {
          out = "// Mal formatedo del comando. Mira \"print\" para mas informaciones.";
          ComlineState.fail();
          break;
        }

        if (printParts[3].equals("XMl"))
          out = StringUtils.prettifyXml(GlobalDataHolder.dragFactura(printParts[2]).toString());
        else if (printParts[3].equals("BNR"))
          out = StringUtils.prettifyJson(GlobalDataHolder.dragFactura(printParts[2]).toSimpleString());
        else
          out = StringUtils.prettifyXml(GlobalDataHolder.dragFactura(printParts[2]).toString());
        ComlineState.success();
      }

      case "facturado" -> {
        if (GlobalDataHolder.dragFacturado(printParts[2]) == null) {
          out = "// El objeto " + printParts[2] + " no existe.";
          ComlineState.fail();
          break;
        }
        if (printParts.length == 3) {
          out = StringUtils.prettifyXml(GlobalDataHolder.dragFacturado(printParts[2]).toString());
          ComlineState.success();
          break;
        }
        if (printParts.length != 4) {
          out = "// Mal formatedo del comando. Mira \"print\" para mas informaciones.";
          ComlineState.fail();
          break;
        }
        if (printParts[3].equals("XMl"))
          out = StringUtils.prettifyXml(GlobalDataHolder.dragFacturado(printParts[2]).toString());
        else if (printParts[3].equals("BNR"))
          out = StringUtils.prettifyJson(GlobalDataHolder.dragFacturado(printParts[2]).toSimpleString());
        else
          out = StringUtils.prettifyXml(GlobalDataHolder.dragFacturado(printParts[2]).toString());
        ComlineState.success();
      }

      case "facturante" -> {
        if (GlobalDataHolder.dragFacturante(printParts[2]) == null) {
          out = "// El objeto " + printParts[2] + " no existe.";
          ComlineState.fail();
          break;
        }
        if (printParts.length == 3) {
          out = StringUtils.prettifyXml(((Facturante) GlobalDataHolder.dragFacturante(printParts[2])).toString());
          ComlineState.success();
          break;
        }
        if (printParts.length != 4) {
          out = "// Mal formatedo del comando. Mira \"print\" para mas informaciones.";
          ComlineState.fail();
          break;
        }
        if (printParts[3].equals("XMl"))
          out = StringUtils.prettifyXml(GlobalDataHolder.dragFacturante(printParts[2]).toString());
        else if (printParts[3].equals("BNR"))
          out = StringUtils.prettifyJson(GlobalDataHolder.dragFacturante(printParts[2]).toSimpleString());
        else
          out = StringUtils.prettifyXml(GlobalDataHolder.dragFacturante(printParts[2]).toString());
        ComlineState.success();
      }

      case "grupo" -> {
        int grupoId = Integer.parseInt(printParts[2]);
        if (GlobalDataHolder.dragGrupo(grupoId) == null) {
          out = "// El objeto " + printParts[2] + " no existe.";
          ComlineState.fail();
          break;
        }
        if (printParts.length == 3) {
          out = Arrays.toString(GlobalDataHolder.dragGrupo(grupoId));
          out = StringUtils.prettifyXml(out.substring(1, out.length() - 1).replaceAll(">, <", "><"));
          ComlineState.success();
          break;
        }
        if (printParts.length != 4) {
          out = "// Mal formatedo del comando. Mira \"print\" para mas informaciones.";
          ComlineState.fail();
          break;
        }
        if (printParts[3].equals("XMl")) {
          out = Arrays.toString(GlobalDataHolder.dragGrupo(grupoId));
          out = StringUtils.prettifyXml(out.substring(1, out.length() - 1).replaceAll(">, <", "><"));
        } else if (printParts[3].equals("BNR")) {
          StringBuffer buffer = new StringBuffer();
          LineaDeFactura[][] grupos = GlobalDataHolder.getGruposDeFacturas();
          for (int j = 0; j < grupos.length; j++) {
            buffer.append("{\"groupID\": " + j + ", \"lineas\": [");
            for (int i = 0; i < grupos[j].length; i++) {
              buffer.append(grupos[j][i].toSimpleString());
              if (i != grupos[j].length - 1)
                buffer.append(",");
            }
            buffer.append("]");
          }
          buffer.append("}");
          out = StringUtils.prettifyJson(buffer.toString());
        } else {
          out = Arrays.toString(GlobalDataHolder.dragGrupo(grupoId));
          out = StringUtils.prettifyXml(out.substring(1, out.length() - 1).replaceAll(">, <", "><"));
        }
        ComlineState.success();
      }

      case "linea" -> {
        int grupoId = Integer.parseInt(printParts[3]);
        if (GlobalDataHolder.dragLineaDeGrupo(grupoId, printParts[2]) == null) {
          out = "// El objeto " + printParts[2] + " no existe en el grupo " + printParts[3];
          ComlineState.fail();
          break;
        }
        if (printParts.length == 4) {
          out = StringUtils
              .prettifyXml(
                  GlobalDataHolder.dragLineaDeGrupo(grupoId, printParts[2]).toString());
          ComlineState.success();
          break;
        }
        if (printParts.length != 5) {
          out = "// Mal formatedo del comando. Mira \"print\" para mas informaciones.";
          ComlineState.fail();
          break;
        }
        if (printParts[4].equals("XMl"))
          out = StringUtils
              .prettifyXml(
                  GlobalDataHolder.dragLineaDeGrupo(grupoId, printParts[2]).toString());
        else if (printParts[4].equals("BNR"))
          out = StringUtils.prettifyJson(
              GlobalDataHolder.dragLineaDeGrupo(grupoId, printParts[2]).toSimpleString());
        else
          out = StringUtils
              .prettifyXml(
                  GlobalDataHolder.dragLineaDeGrupo(grupoId, printParts[2]).toString());
        ComlineState.success();
      }

      default -> {
        out = "// Mal formatedo del comando. Mira \"print\" para mas informaciones.";
        ComlineState.fail();
      }
    }

    Debug.println(out);
  }
}
