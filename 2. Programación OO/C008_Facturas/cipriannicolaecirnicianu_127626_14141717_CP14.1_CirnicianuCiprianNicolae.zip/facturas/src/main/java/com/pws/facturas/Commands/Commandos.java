package com.pws.facturas.Commands;

import com.pws.facturas.GlobalDataHolder;
import com.pws.facturas.datatypes.ComlineState;
import com.pws.facturas.utils.Debug;
import com.pws.facturas.utils.Factory;
import com.pws.facturas.utils.StringUtils;

public class Commandos {
  public static boolean run(String com) {
    ComlineState.success();
    if (com.length() == 0)
      return true;
    String[] comParts = StringUtils.breakApart(com);
    if (C_Options.autoClear)
      new C_Celar();

    switch (comParts[0].toLowerCase()) {
      case "exit":
        if (C_Options.autoExit) return false;
        return !Factory.prompt1V2("// Estas seguro que quieres salir? Toda la informacion cargada se va a perder.", "s", "n", false);

      case "help":
        new C_Help();
        return true;

      case "clear":
        new C_Celar();
        return true;

      case "gdata":
        globalDataCommand(comParts);
        return true;

      case "options":
        new C_Options(com);
        return true;

      case "crea":
        new C_Create(com);
        return true;

      case "borra":
        new C_Borra(com);
        return true;

      case "modifica":
        new C_Modifica(com);
        return true;

      case "print":
        new C_Print(com);
        return true;

      case "savexml":
        C_XML.saveXml(com);
        return true;

      case "savebnr":
        C_BNR.saveBnr(com);
        return true;

      case "loadxml":
        C_XML.loadXml(com);
        return true;

      case "loadbnr":
        C_BNR.loadBnr(com);
        return true;

      default:
        if (!com.equals(""))
          Debug.print("// Comando " + com + " no se encontro.\n");
        return true;
    }
  }

  private static void globalDataCommand(String[] comParts) {
    if (comParts.length == 1) {
      Debug.print(GlobalDataHolder.staticToString());
      ComlineState.success();
      return;
    }
    if (comParts.length != 2) {
      Debug.print(
          "// El comando no tiene el tamano apropriado. El sintaxis es: gdata [XML o BNR].");
      ComlineState.fail();
      return;
    }
    if (comParts[1].toUpperCase().equals("XML"))
      Debug.print(GlobalDataHolder.staticToString());
    else if (comParts[1].toUpperCase().equals("BNR"))
      Debug.print(GlobalDataHolder.staticToSimpleString());
    else
      Debug.print(GlobalDataHolder.staticToString());
    ComlineState.success();
  }
}
