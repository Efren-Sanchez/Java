package com.pws.facturas.datatypes;

public enum IVA {
  NORMAL(21),
  REDUCIDO(10),
  SUPERREDUCIDO(4);

  private int percentage = 0;

  private IVA(int percentage) {
    this.percentage = percentage;
  }

  public int getPercentage() {
    return percentage;
  }

  /**
   * Returns the IVA type based on the percentage provided. if it isn't any of the percentages 
   * stored inside the enum data, it returns the closest percentage number or NORMAL.
   * @param percentage the percentage to look for.
   * @return the IVA enum or IVA.NORMAL if nothing found.
   */
  public static IVA get(int percentage) {
    if(percentage <= NORMAL.getPercentage())return NORMAL;
    else if (percentage <= REDUCIDO.getPercentage()) return REDUCIDO;
    else if (percentage <= SUPERREDUCIDO.getPercentage()) return SUPERREDUCIDO;

    return IVA.NORMAL;
  }

  /**
   * Returns the IVA type based on the name provided. if it isn't any of the name 
   * stored inside the enum data, it returns IVA.NORMAL. (the values are NORMAL REDUCIDO and SUPERREDUCIDO)
   * @param name the name to look for,
   * @return the IVA enum or IVA.NORMAL if nothing found.
   */
  public static IVA get(String name) {
    if(name.toUpperCase().equals("NORMAL")) return NORMAL;
    else if(name.toUpperCase().equals("REDUCIDO")) return REDUCIDO;
    else if(name.toUpperCase().equals("SUPERREDUCIDO")) return SUPERREDUCIDO;

    return NORMAL;
  }

  @Override
  public String toString() {
    if (this.getPercentage() == NORMAL.getPercentage()) return "NORMAL";
    else if (this.getPercentage() == REDUCIDO.getPercentage()) return "REDUCIDO";
    else if (this.getPercentage() == SUPERREDUCIDO.getPercentage()) return "SUPERREDUCIDO";

    return "NORMAL";
  }
}
