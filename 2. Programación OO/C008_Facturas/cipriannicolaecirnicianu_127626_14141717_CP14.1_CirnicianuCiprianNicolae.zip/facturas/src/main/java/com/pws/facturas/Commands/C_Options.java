package com.pws.facturas.Commands;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.pws.facturas.GlobalDataHolder;
import com.pws.facturas.datatypes.ComlineState;
import com.pws.facturas.datatypes.Factura;
import com.pws.facturas.datatypes.Facturado;
import com.pws.facturas.datatypes.Facturante;
import com.pws.facturas.datatypes.FileManager;
import com.pws.facturas.datatypes.LineaDeFactura;
import com.pws.facturas.datatypes.PFloat;
import com.pws.facturas.utils.Debug;
import com.pws.facturas.utils.StringUtils;

import java.io.File;

public class C_Options {
  public static final byte tabSize = 2;
  public static byte localTabSize = tabSize;
  public static ComlineState comlineState = ComlineState.SUCCESS;
  public static String fPointPrecision = Integer.toUnsignedString(10000);
  public static boolean autoClear = false;
  public static boolean autoExit = false;
  public static File defaultLaunchFile = null;


  public C_Options() {
    resetGlobalData();
  
    File optionsFile = FileManager.getFile("/data/system/options.json");
    if (optionsFile == null || !optionsFile.exists()) {
      // Try creating the file
      optionsFile = FileManager.createFile("/data/system/options.json");
      FileManager.updateFile(optionsFile, "", false, false);

      if (optionsFile != null) {
        saveOptionsToFile(); // Save the defaults immediately
      }
    } else {
      loadOptionsFromFile(); // If file exists, load existing values
    }
  
    loadDefaultLaunchFile();
  }
  

  public C_Options(String com) {
    String[] optionParts = StringUtils.breakApart(com);

    if (optionParts.length == 1) {
      Debug.print(
      """
      /------------------------------
      | options defaultLaunchFile [nombre ficero .xml O .json] -> setea la factura que quieres iniciar por defecto, y iniciarlo.
      |       \\> dehar vacio si no quieres ninguno.
      |
      | options defaultTabSize [tamano tab] -> setea el tamano del tab en los prints, y ficeros. no midifica los ficheros ya existentes.
      |       \\> para eso, carga el fichero, y guardalo otra vez despues de modificar ese opcion.
      |
      | options floatingPrecision [numero de precision] -> setea el nivel de precision de los numeros flotantes como los precios.
      |       \\> pone un 1 con tantos 0 como decimales quieres. El minimo es 10.
      | options enableAutoClear [s o n] -> el rograma va a limpiar el terminal cada vez antes del siguiente comando.
      |       \\> equivalente a >> clear >> nextCommand
      | options enableAutoExit [s o n] -> el programa va a salir directamente sin el mensaje de confirmacion.
      | options reload -> reinicia todo el programa, como si fuese cerrado y iniciado desde 0.
      |
      !! PELIGO: Antes de cambiar cualquier infomacion, guarda la informacion que quieres salvar. Todos los cambios de las opciones del sistema
      !!         borran los datos cargados.
      \\------------------------------
      """);
      ComlineState.success();
      return;
    }

    switch (optionParts[1]) {
      case "defaultLaunchFile":
        handleDefaultLaunchFile(optionParts);
        break;
      case "defaultTabSize":
        handleDefaultTabSize(optionParts);
        break;
      case "floatingPrecision":
        handleFloatingPrecision(optionParts);
        break;
      case "enableAutoClear":
        handleEnableAutoClear(optionParts);
        break;
      case "enableAutoExit":
        handleEnableAutoExit(optionParts);
        break;
      case "reload":
        handleReload();
        break;
      default:
        Debug.println("Commado " + com + " no se encontro.");
        ComlineState.fail();
        break;
    }

    saveOptionsToFile();
    loadOptionsFromFile();
  }

  private void handleDefaultLaunchFile(String[] optionParts) {
    if (optionParts.length == 2) {
      defaultLaunchFile = null;
    } else if (optionParts.length == 3) {
      String fileName = optionParts[2];
      if (fileName.endsWith(".json"))
        defaultLaunchFile = FileManager.getFile("/data/bnr/" + fileName);
      else if (fileName.endsWith(".xml"))
        defaultLaunchFile = FileManager.getFile("/data/xml/" + fileName);
      else
        defaultLaunchFile = null;
    } else {
      Debug.println("//  Mal formatedo del comando.");
      ComlineState.fail();
      return;
    }

    if (defaultLaunchFile != null) {
      Debug.println("//  La factura por defecto es: " + defaultLaunchFile.getAbsolutePath());
      ComlineState.success();
    }
  }

  private void handleDefaultTabSize(String[] optionParts) {
    if (optionParts.length == 2) {
      localTabSize = tabSize;
      Debug.println("//  El tamano del tab ahora es " + localTabSize + ". El valor por defecto.");
    } else if (optionParts.length == 3) {
      try {
        localTabSize = Byte.valueOf(optionParts[2]);
        Debug.println("//  El tamano del tab ahora es " + localTabSize + ".");
        ComlineState.success();
      } catch (NumberFormatException e) {
        Debug.println("//  Tamano del tab invalido.");
        ComlineState.fail();
        return;
      }
    } else {
      Debug.println("//  Mal formatedo del comando.");
      ComlineState.fail();
      return;
    }
    ComlineState.success();
  }

  private void handleFloatingPrecision(String[] optionParts) {
    if (optionParts.length == 2) {
      PFloat.resetDecimalDigits();
      Debug.println("//  La precision de los numeros flotantes es ahora " + PFloat.getDecimalDigits() + ". El valor por defecto.");
    } else if (optionParts.length == 3) {
      try {
        if (!optionParts[2].matches("10+"))
          throw new NumberFormatException();
        PFloat.setDecimalDigits(Integer.parseUnsignedInt(optionParts[2]));
        Debug.println("//  La precision de los numeros flotantes es ahora " + PFloat.getDecimalDigits() + ".");
        ComlineState.success();
      } catch (NumberFormatException e) {
        Debug.println("//  Formateo de la precision de los numeros flotantes invalido.");
        ComlineState.fail();
        return;
      }
    } else {
      Debug.println("//  Mal formatedo del comando.");
      ComlineState.fail();
      return;
    }

    ComlineState.success();
  }

  private void handleEnableAutoClear(String[] optionParts) {
    if (optionParts.length == 2) {
      autoClear = false;
      Debug.println("//  Auto-clear es ahora desactivado.");
      ComlineState.success();
    } else if (optionParts.length == 3) {
      autoClear = optionParts[2].toLowerCase().equals("true");
      Debug.println("//  Auto-clear es ahora " + (autoClear ? "activado." : "desactivado."));
      ComlineState.success();
    } else {
      Debug.println("//  Mal formatedo del comando.");
      ComlineState.fail();
      return;
    }
  }

  private void handleEnableAutoExit(String[] optionParts) {
    if (optionParts.length == 2) {
      autoExit = false;
      Debug.println("//  Auto-exit es ahora desactivado.");
      ComlineState.success();
    } else if (optionParts.length == 3) {
      autoExit = optionParts[2].toLowerCase().equals("true");
      Debug.println("//  Auto-exit es ahora " + (autoExit ? "activado." : "desactivado."));
      ComlineState.success();
    } else {
      Debug.println("//  Mal formatedo del comando.");
      ComlineState.fail();
      return;
    }
  }

  private void handleReload() {
    resetGlobalData();
    loadDefaultLaunchFile();
    ComlineState.success();
    Debug.println("//  Optiones y informacion recardados.");
  }

  public static void loadDefaultLaunchFile() {
    if (defaultLaunchFile != null) {
      if (defaultLaunchFile.getName().endsWith(".json")) {
        String jsonName = defaultLaunchFile.getName().replace(".json", "");
        C_BNR.loadBnr("loadBnr " + jsonName);
      } else if (defaultLaunchFile.getName().endsWith(".xml")) {
        String xmlName = defaultLaunchFile.getName().replace(".xml", "");
        C_XML.loadXml("loadXml " + xmlName);
      }
    }
  }

  public void resetGlobalData() {
    Debug.println("//  Reseteando informacion cargada...");
    GlobalDataHolder.setFacturados(new Facturado[0]);
    GlobalDataHolder.setFacturantes(new Facturante[0]);
    GlobalDataHolder.setFacturas(new Factura[0]);
    GlobalDataHolder.setGruposDeFacturas(new LineaDeFactura[0][0]);
  }

  private void saveOptionsToFile() {
    String completeBnr = StringUtils.prettifyJson(this.toString());
    File bnrFile = FileManager.getFile("/data/system/options.json");
  
    if (bnrFile == null || !bnrFile.exists()) {
      bnrFile = FileManager.createFile("/data/system/options.json");
    }
  
    if (bnrFile != null) {
      FileManager.updateFile(bnrFile, completeBnr, false, false);
      Debug.println("//  Opciones guardadas.");
    } else {
      Debug.println("//  Error guardando opciones.");
    }
  }
  

  public void loadOptionsFromFile() {
    File optionsFile = FileManager.getFile("/data/system/options.json");

    if(optionsFile == null) {
      optionsFile = FileManager.createFile("/data/system/options.json");
      saveOptionsToFile();
    } else if (optionsFile != null && optionsFile.exists()) {
      try {
        JsonElement jsonData = FileManager.loadJson(optionsFile.getAbsolutePath());
        if (jsonData != null && jsonData.isJsonObject()) {
          JsonObject jOptions = jsonData.getAsJsonObject();
          String jDefaultlaunchFilePath = jOptions.get("defaultLaunchFile").getAsString();
          if (jDefaultlaunchFilePath != null && !jDefaultlaunchFilePath.isEmpty()) {
            if (jDefaultlaunchFilePath.endsWith(".json"))
              defaultLaunchFile = FileManager.getFile("/data/bnr/" + jDefaultlaunchFilePath);
            else if (jDefaultlaunchFilePath.endsWith(".xml"))
              defaultLaunchFile = FileManager.getFile("/data/xml/" + jDefaultlaunchFilePath);
            else
              defaultLaunchFile = null;
          } else {
            defaultLaunchFile = null;
          }

          fPointPrecision = jOptions.get("fPointPrecision").getAsString();
          autoClear = jOptions.get("autoClear").getAsBoolean();
          autoExit = jOptions.get("autoExit").getAsBoolean();

          if (Integer.parseUnsignedInt(fPointPrecision) < 10)
            fPointPrecision = "10";
          PFloat.setDecimalDigits(Integer.parseUnsignedInt(fPointPrecision));

          Debug.println("//  Opciones cargados con exito.");
        } else {
          Debug.println("//  Fichero de opciones invalido.");
        }
      } catch (Exception e) {
        Debug.logError(e);
        Debug.println("//  Error cargando opciones.");
      }
    }
  }

  @Override
  public String toString() {
    return "{" +
        "\"defaultLaunchFile\":\"" + (defaultLaunchFile == null ? "" : defaultLaunchFile.getName()) + "\", " +
        "\"fPointPrecision\":\"" + fPointPrecision + "\", " +
        "\"autoClear\":" + autoClear + ", " +
        "\"autoExit\":" + autoExit +
        "}";
  }
}
