package com.pws.facturas.datatypes;

import java.time.LocalDateTime;
import java.util.Arrays;

public class Factura {
  private String varName = super.toString();
  private Facturante facurante = new Facturante(null, null, null, null, null);
  private Facturado facturado = new Facturado(null, null);
  private LocalDateTime fechaYHora = LocalDateTime.now();
  private int numeroFactura = Integer.parseUnsignedInt("0");
  private LineaDeFactura[] lineasFactura = new LineaDeFactura[0];
  private PFloat totalFactura = new PFloat();

  public Factura() {
  }

  public Factura(Factura original) {
    this.facturado = original.facturado;
    this.facturado = original.facturado;
    this.fechaYHora = original.fechaYHora;
    this.numeroFactura = original.numeroFactura;
    this.lineasFactura = original.lineasFactura;
    this.totalFactura = original.totalFactura;
  }

  public Factura(Facturante facturante, Facturado facturado, LocalDateTime fechaYHora, int numeroFactura, LineaDeFactura[] lineasFactura, PFloat totalFactura) {
    this.facurante = facturante;
    this.facturado = facturado;
    this.fechaYHora = fechaYHora;
    this.numeroFactura = numeroFactura;
    this.lineasFactura = lineasFactura;
    this.totalFactura = totalFactura;
  }

  @Override
  public String toString() {
    return "<factura>" +
        "<varName>" + varName + "</varName>" +
        facurante.toString() +
        facturado.toString() +
        "<fecha>" + fechaYHora.toString() + "</fecha>" +
        "<numeroFactura>" + numeroFactura + "</numeroFactura>" +
        "<lineasFactura>" + Arrays.toString(lineasFactura).replace(", ", "").replace("[", "").replace("]", "")
        + "</lineasFactura>" +
        "<totalFactura>" + totalFactura.toString() + "</totalFactura>" +
        "</factura>";
  }

  public String toSimpleString() {
    StringBuffer lineas = new StringBuffer();
    for (int i = 0; i < lineasFactura.length; i++) {
      lineas.append(lineasFactura[i].toSimpleString());
      if(i != lineasFactura.length -1) lineas.append(",");
    }

    return "\"factura\": {" +
        "\"varname\": \"" + varName + "\"," +
        "\"facturante\": {" + facurante.toSimpleString() + "}, " +
        "\"facturado\": {" + facturado.toSimpleString() + "}, " +
        "\"fechayhora\": \"" + fechaYHora.toString() + "\", " +
        "\"numeroFactura\": \"" + numeroFactura + "\", " +
        "\"lineas\": [" + lineas.toString() + "],"+
        "\"totalfactura\": \"" + totalFactura.toString() + "\""+
        "}";
  }

  public static PFloat calculateTotal(LineaDeFactura[] lineaDeFacturas) {
    PFloat resultado = new PFloat();
    for (LineaDeFactura linea : lineaDeFacturas) {
      resultado.add(linea.total());
    }
    return resultado;
  }

  public Facturante getFacurante() {
    return facurante;
  }

  public Facturado getFacturado() {
    return facturado;
  }

  public LocalDateTime getFechaYHora() {
    return fechaYHora;
  }

  public int getNumeroFactura() {
    return numeroFactura;
  }

  public LineaDeFactura[] getLineasFactura() {
    return lineasFactura;
  }

  public PFloat getTotalFactura() {
    return totalFactura;
  }

  public String getVarName() {
    return varName;
  }

  public void setFacurante(Facturante facurante) {
    this.facurante = facurante;
  }

  public void setFacturado(Facturado facturado) {
    this.facturado = facturado;
  }

  public void setFechaYHora(LocalDateTime fechaYHora) {
    this.fechaYHora = fechaYHora;
  }

  public void setNumeroFactura(int numeroFactura) {
    this.numeroFactura = numeroFactura;
  }

  public void setLineasFactura(LineaDeFactura[] lineasFactura) {
    this.lineasFactura = lineasFactura;
  }

  public void setTotalFactura(PFloat totalFactura) {
    this.totalFactura = totalFactura;
  }

  public void setVarName(String varName) {
    this.varName = varName;
  }
}
