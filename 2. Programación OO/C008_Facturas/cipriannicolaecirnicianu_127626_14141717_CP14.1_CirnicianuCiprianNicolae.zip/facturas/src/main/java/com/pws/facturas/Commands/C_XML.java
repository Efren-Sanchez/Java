package com.pws.facturas.Commands;

import java.io.File;
import java.time.LocalDateTime;
import java.util.Arrays;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.pws.facturas.GlobalDataHolder;
import com.pws.facturas.datatypes.ComlineState;
import com.pws.facturas.datatypes.Factura;
import com.pws.facturas.datatypes.Facturado;
import com.pws.facturas.datatypes.Facturante;
import com.pws.facturas.datatypes.FileManager;
import com.pws.facturas.datatypes.IVA;
import com.pws.facturas.datatypes.LineaDeFactura;
import com.pws.facturas.datatypes.PFloat;
import com.pws.facturas.utils.Debug;
import com.pws.facturas.utils.StringUtils;

public class C_XML {
  private static String[] dataMesh = new String[0];
  private static String[][] dataLineas = new String[0][0];

  public static void saveXml(String com) {
    String[] xmlParts = StringUtils.breakApart(com);

    if (xmlParts.length == 1) {
      System.out.print(
      """
      /------------------------------
      | saveXML -> guarda una factura en "/data/xml/[identificador].xml".
      | loadXML  -> carga los datos de una factura.
      \\------------------------------
      """);
      ComlineState.fail();
      return;
    } else if (xmlParts.length == 2) {
      StringBuilder xml = new StringBuilder(GlobalDataHolder.dragFactura(xmlParts[1]).toString());
      String completeXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + StringUtils.prettifyXml(xml.toString());
      File xmlFile = FileManager.createFile("/data/xml/" + xmlParts[1] + ".xml");
      FileManager.updateFile(xmlFile, completeXml, false, false);
      Debug.println("//  Fichero " + xmlFile.getAbsolutePath() + " se cargo con exito.");
      ComlineState.success();
    } else {
      Debug.print("// Mal formatedo del comando.");
      ComlineState.fail();
    }
  }

  public static void loadXml(String com) {
    String[] xmlParts = StringUtils.breakApart(com);

    if (xmlParts.length == 1) {
      System.out.print(
          """
          /------------------------------
          | saveXML -> guarda una factura en "/data/xml/[identificador].xml".
          | loadXML  -> carga los datos de una factura.
          \\------------------------------
          """);
      ComlineState.fail();
      return;
    } else if (xmlParts.length == 2) {
      File xmlFile = FileManager.getFile("/data/xml/" + xmlParts[1] + ".xml");
      if (xmlFile == null) {
        Debug.print("// File " + xmlParts[1] + ".xml not found.");
        ComlineState.fail();
        return;
      }

      parseNode(FileManager.parseXml(FileManager.readFile(xmlFile)), 0);

      LineaDeFactura[] lineas = new LineaDeFactura[0];
      for (String[] dataLinea : dataLineas) {
        lineas = Arrays.copyOf(lineas, lineas.length + 1);
        lineas[lineas.length - 1] = new LineaDeFactura();
        lineas[lineas.length - 1].setVarName(dataLinea[0]);
        lineas[lineas.length - 1].setArticulo(dataLinea[1]);
        try {lineas[lineas.length - 1].setCantidad(Integer.parseUnsignedInt(dataLinea[2]));}
        catch (NumberFormatException e) {
          Debug.println(ComlineState.FAIL.getPrint() + " La cantidad no es un numero entero valido.");
          return;
        }
        try {lineas[lineas.length - 1].setPrecio(new PFloat(dataLinea[3]));}
        catch (NumberFormatException e) {
          Debug.println(ComlineState.FAIL.getPrint() + " El precio no es un numero flotante valido.");
          return;
        }
        lineas[lineas.length - 1].setIva(IVA.get(Integer.parseInt(dataLinea[4])));
      }
      
      Factura factura = new Factura(
          new Facturante(
              dataMesh[2],
              dataMesh[3],
              dataMesh[4],
              dataMesh[5],
              dataMesh[6]),
          new Facturado(
              dataMesh[8],
              dataMesh[9]),
          LocalDateTime.parse(dataMesh[10]),
          Integer.parseInt(dataMesh[11]),
          lineas,
          new PFloat(dataMesh[dataMesh.length - 1]));

      factura.setVarName(dataMesh[0]);
      factura.getFacurante().setVarName(dataMesh[1]);
      factura.getFacturado().setVarName(dataMesh[7]);

      GlobalDataHolder.putIntoFacturas(factura);
      GlobalDataHolder.putIntoFacturados(factura.getFacturado());
      GlobalDataHolder.putIntoFacturantes(factura.getFacurante());
      int group = GlobalDataHolder.putNewGroup();
      for (LineaDeFactura lineaDeFactura : lineas) {
        GlobalDataHolder.putIntoGruposLinea(group, lineaDeFactura);
      }

      Debug.println("//  Fichero " + xmlFile.getAbsolutePath() + " se cargo con exito.");
      ComlineState.success();
    } else {
      Debug.print("Mal formatedo del comando.");
      ComlineState.fail();
    }
  }

  private static void parseNode(Node node, int depth) {

    if (node.getNodeType() == Node.ELEMENT_NODE) {
      Element element = (Element) node;

      // Process child nodes
      NodeList children = element.getChildNodes();
      boolean hasElementChildren = false;

      // Check if there are any element children
      for (int i = 0; i < children.getLength(); i++) {
        if (children.item(i).getNodeType() == Node.ELEMENT_NODE) {
          hasElementChildren = true;
          break;
        }
      }

      if (hasElementChildren) {
        for (int i = 0; i < children.getLength(); i++) {
          Node child = children.item(i);
          if (child.getNodeType() == Node.ELEMENT_NODE) {
            parseNode(child, depth + 1);
          }
        }
      } else {
        // Handle text content for leaf nodes
        String content = element.getTextContent().trim();
        String nodeName = element.getNodeName();
        if (element.getParentNode().getNodeName().equals("lineaDeFactura")) {
          if (nodeName.equals("varName")) {
            dataLineas = Arrays.copyOf(dataLineas, dataLineas.length + 1);
            dataLineas[dataLineas.length - 1] = new String[5];
            dataLineas[dataLineas.length - 1][0] = content;
          } else if (nodeName.equals("articulo")) {
            if (dataLineas.length > 0)
              dataLineas[dataLineas.length - 1][1] = content;
          } else if (nodeName.equals("cantidad")) {
            if (dataLineas.length > 0)
              dataLineas[dataLineas.length - 1][2] = content;
          } else if (nodeName.equals("precio")) {
            if (dataLineas.length > 0)
              dataLineas[dataLineas.length - 1][3] = content;
          } else if (nodeName.equals("iva")) {
            if (dataLineas.length > 0)
              dataLineas[dataLineas.length - 1][4] = content;
          }
        } else {
          dataMesh = Arrays.copyOf(dataMesh, dataMesh.length + 1);
          dataMesh[dataMesh.length - 1] = content;
        }
      }
    }
  }
}