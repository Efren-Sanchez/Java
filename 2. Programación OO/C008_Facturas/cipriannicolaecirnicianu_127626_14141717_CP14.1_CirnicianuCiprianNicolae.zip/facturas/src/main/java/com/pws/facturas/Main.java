package com.pws.facturas;

import com.pws.facturas.Commands.C_Celar;
import com.pws.facturas.Commands.C_Options;
import com.pws.facturas.Commands.Commandos;
import com.pws.facturas.utils.Debug;
import com.pws.facturas.utils.Input;

public class Main {
	public static void main(String[] args) {
		new C_Celar();
		GlobalDataHolder.opts = new C_Options();
		Input.create();
		Debug.println("//  Para empezar usar el programa, escribe \"help\" y pulsa enter. Para mas informacion, ver README.md");

		try {
			while (Commandos.run(Input.read())) {
				// do the thing.
			}
			Debug.println("//  Exiting Program. Follow the powershell instructions to close the terminal and the program or to start it back up.");
		} catch (Exception e) {
			Debug.logError(e);
		}
	}
}