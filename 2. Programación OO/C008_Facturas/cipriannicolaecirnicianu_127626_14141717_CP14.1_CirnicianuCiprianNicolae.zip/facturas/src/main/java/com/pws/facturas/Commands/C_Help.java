package com.pws.facturas.Commands;

import com.pws.facturas.datatypes.ComlineState;
import com.pws.facturas.utils.Debug;

public class C_Help {
  public C_Help() {
    Debug.print(
    """
    /------------------------------
    | exit -> sale del programa
    | help -> te escribe ese texto
    | clear -> limpia el terminal
    | gdata -> escribe los datos globales guargados en el programa.
    | options -> para modificar las opciones del sistema.
    |
    | crea -> crea un elemento
    | borra -> borra un elemento
    | modifica -> modifica un elemento
    | print -> escribe un elemento
    |
    | saveXml -> guarda una factura en /data/xml/[idenfificador].xml.
    | loadXml -> carga los datos de una factura.
    |
    | saveBnr -> guarda una factura en "/data/bnr/[idenfificador].json"
    | loadBnr -> carga los datos de una factura.
    |
    | Escribe el comando que euieres usar sin argumentos para mas informacion. (no todos tienen, como exit, o clear.)
    | Si quieres crear una factura, usa \"crea factura factury\" y siguie las instrucciones.
    | Puedes usar <TAB> para auto completar texto y con <FLECHA-UP> y <FLECHA-DOWN> puedes navigar comandos pasados.
    \\------------------------------
    """);
    ComlineState.success();
  }
}
