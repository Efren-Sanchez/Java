    ⚠️ Si usas VS Code, presiona Ctrl + Shift + V para ver correctamente este README.

Este programa permite crear "Facturas" directamente desde la terminal, de forma simple y rápida.

0. 🧪 Demostración rápida (Copiar y pegar)

Aqui esta un pequieno ejemplo de crear una facturan con bulk, que crea con 3 lineas nuevas y printa los datos finales.

    crea grupo
    crea linea ln1 0 a 1 0.0 NORMAL
    crea linea ln2 0 a 1 0.0 REDUCIDO
    crea linea ln3 0 a 1 0.0 SUPERREDUCIDO
    crea facturado fo1 Pepe 123
    crea facturante fe1 GUGU a 123 4256157 some@email.com
    crea factura fc1 fe1 fo1 12 0
    gdata


1. 🔡 Códigos de escape

El sistema soporta varios códigos para controlar el texto:

	Código	Función

	\s	Une las palabras antes y después como una sola. Ej: Maria\ Evvins → "Maria Evvins"

	\n	Salto de línea

	\t	Tabulación (la que define Java, no el programa)

	\' o \"	Imprime comillas simples o dobles

\\\\	Imprime una barra invertida (\\)

2. 🧊 Comillas

El sistema tambien soporta agrupar elementos con comillas.

	Dobles ": Agrupan el texto literalmente (no se interpretan los escapes).
	Ejemplo: "El \n se queda como \n"

	Simples ': Interpretan los códigos de escape.
	Ejemplo: 'Este \"texto\" está entre comillas.' → Este "texto" está entre comillas.

3. 🏭 Fábricas

Puedes usar fábricas para crear objetos paso a paso.

    Comandos como crea y modifica usan este sistema.

    Ideal para aprender o cuando hay muchas variables.

    Si los nombres tienen espacios, normalmente hay que usar comillas o escapes.
    Dentro de la fábrica no es necesario.

4. 📦 Modo rápido (Bulk)

Muchos comandos también permiten crear objetos rápidamente.

    Sintaxis:
    crea [tipo] [id] [valores...]
    Ejemplo:
    crea facturante fe1 Pepe 11223344

    Útil si necesitas crear muchas cosas rápido.

    Para una sola factura, la fábrica puede ser más fácil.

5. 🧾 Lista de comandos

Ejecuta cualquier comando sin parámetros para ver más info.

	Comando	Función
	exit	Cierra el programa. Pregunta antes de salir. ¡Cuidado con la pérdida de datos!
	help	Muestra la lista de comandos
	clear	Limpia la terminal
	gdata	Imprime los datos cargados. Por defecto en XML, usa xml o bnr para JSON

	options	Cambia opciones del programa (Factura inicial, tabulaciones, etc.)

	crea	Crea un objeto (modo rápido o fábrica)
	borra	Elimina un objeto (línea, grupo, etc.)
	modifica	Edita un objeto (modo rápido o fábrica)
	print	Muestra un objeto en XML o JSON (bnr). XML por defecto
	
	saveXml	Guarda la factura como /data/xml/[id].xml
	loadXml	Carga una factura desde /data/xml/[id].xml (sin poner .xml)
	saveBnr	Guarda como /data/bnr/[id].json
	loadBnr	Carga desde /data/bnr/[id].json (sin .json)