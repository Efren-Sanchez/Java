# Parecer ser que JAXB fue eliminada del JDK en Java 11 (sobre 2018),
por lo que he buscado las dependencias manualmente y las he descargado.

# Para practicar un poco y tratar de coger buenas costumbres,
he creado un pequeño pom.xml a mano con las dependencias descargadas.

# Poco que decir sobre la librería de JSON.
JSON.simple no puede formatear el JSON para que se vea bonito.