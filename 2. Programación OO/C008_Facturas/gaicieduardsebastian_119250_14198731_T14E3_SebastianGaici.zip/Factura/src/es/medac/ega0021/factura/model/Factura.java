package es.medac.ega0021.factura.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlTransient;

@XmlRootElement
public class Factura {

    /***** Atributos *****/
    private static int contadorFacturas = 1;

    private int numeroFactura;
    private LocalDateTime fechaEmision;
    private Empresa empresa;
    private Cliente cliente;
    private LineaFactura[] lineasFactura;
    private int contadorLineas;

    /***** Constructores *****/
    public Factura() {
        this.numeroFactura = contadorFacturas++;
        this.fechaEmision = LocalDateTime.now();
        this.empresa = new Empresa();
        this.cliente = new Cliente();
        this.lineasFactura = new LineaFactura[5];
        this.contadorLineas = 0;
    }

    public Factura(Empresa empresa) {
        this.numeroFactura = contadorFacturas++;
        this.fechaEmision = LocalDateTime.now();
        this.empresa = empresa;
        this.cliente = new Cliente();
        this.lineasFactura = new LineaFactura[5];
        this.contadorLineas = 0;
    }

    public Factura(LocalDateTime fechaEmision, Empresa empresa, Cliente cliente, LineaFactura[] lineasFactura) {
        this.numeroFactura = contadorFacturas++;
        this.fechaEmision = fechaEmision;
        this.empresa = empresa;
        this.cliente = cliente;
        for (int i = 0; i < lineasFactura.length; i++) {
            this.lineasFactura[i] = lineasFactura[i];
        }
        this.contadorLineas = 0;
    }

    public Factura(Factura f) {
        this.numeroFactura = f.numeroFactura;
        this.fechaEmision = f.fechaEmision;
        this.empresa = f.empresa;
        this.cliente = f.cliente;
        for (int i = 0; i < f.lineasFactura.length; i++) {
            this.lineasFactura[i] = f.lineasFactura[i];
        }
        this.contadorLineas = f.contadorLineas;
    }

    /***** Getters y Setters *****/
    @XmlElement
    public int getNumeroFactura() {
        return numeroFactura;
    }

    public void setNumeroFactura(int numeroFactura) {
        this.numeroFactura = numeroFactura;
    }

    @XmlTransient
    public LocalDateTime getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(LocalDateTime fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    @XmlElement
    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    @XmlElement
    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    @XmlElement
    public LineaFactura[] getLineasFactura() {
        LineaFactura[] lineasValidas = new LineaFactura[contadorLineas];
        for (int i = 0; i < contadorLineas; i++) {
            lineasValidas[i] = lineasFactura[i];
        }
        return lineasValidas;
    }

    public void setLineasFactura(LineaFactura[] lineasFactura) {
        this.lineasFactura = lineasFactura;
    }

    @XmlElement
    public int getcontadorLineas() {
        return contadorLineas;
    }

    public void setcontadorLineas(int contadorLineas) {
        this.contadorLineas = contadorLineas;
    }

    /***** Métodos *****/
    public void agregarLinea(LineaFactura lineaFactura) {
        // Ampliar el vector de líneas si ya no queda espacio
        if (contadorLineas == lineasFactura.length) {
            ampliarVectorLineasFactura();
        }
        lineasFactura[contadorLineas] = lineaFactura;
        contadorLineas++;
    }

    public double calcularBaseImponible() {
        double baseImponible = 0.0;
        for (int i = 0; i < contadorLineas; i++) {
            baseImponible += lineasFactura[i].calcularSubtotal();
        }
        return baseImponible;
    }

    public double calcularIVA() {
        double iva = 0.0;
        for (int i = 0; i < contadorLineas; i++) {
            iva += lineasFactura[i].calcularIVA();
        }
        return iva;
    }

    public double calcularTotal() {
        return calcularBaseImponible() + calcularIVA();
    }

    /***** Métodos auxiliares *****/
    public void ampliarVectorLineasFactura() {
        // Crear un nuevo vector 1.5x más grande
        int nuevoTamanyo = (int) (lineasFactura.length * 1.5) + 1;
        // Vector temporal con el nuevo tamaño
        LineaFactura[] vecTemporal = new LineaFactura[nuevoTamanyo];
        // Copiar los elementos del vector original al temporal
        for (int i = 0; i < lineasFactura.length; i++) {
            vecTemporal[i] = lineasFactura[i];
        }
        // Apuntar el vector original al nuevo
        lineasFactura = vecTemporal;
    }

    private String lineasFacturaToString() {
        StringBuilder resultado = new StringBuilder();
        for (int i = 0; i < contadorLineas; i++) {
            resultado.append(lineasFactura[i].toString());
            if (i < contadorLineas - 1) {
                resultado.append("\n\n");
            }
        }
        return resultado.toString();
    }

    /***** Métodos comunes *****/
    @Override
    public String toString() {
        return String.format("""
                Factura nº: %d
                Fecha: %s

                === Empresa ===
                %s

                === Cliente ===
                %s

                === Líneas de factura [%d] ===
                %s

                === Totales ===
                Base imponible: %.2f €
                IVA total: %.2f €
                Total factura: %.2f €""",
                numeroFactura,
                DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm").format(fechaEmision),
                empresa.toString(),
                cliente.toString(),
                contadorLineas,
                lineasFacturaToString(),
                calcularBaseImponible(),
                calcularIVA(),
                calcularTotal());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;

        Factura objConvertido = (Factura) obj;

        return Objects.equals(this.empresa, objConvertido.empresa) &&
                Objects.equals(this.cliente, objConvertido.cliente) &&
                this.numeroFactura == objConvertido.numeroFactura &&
                Objects.equals(this.fechaEmision, objConvertido.fechaEmision) &&
                Objects.equals(this.lineasFactura, objConvertido.lineasFactura) &&
                this.contadorLineas == objConvertido.contadorLineas;
    }
}
