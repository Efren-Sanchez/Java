package es.medac.ega0021.factura.util;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import es.medac.ega0021.factura.model.Cliente;
import es.medac.ega0021.factura.model.Empresa;
import es.medac.ega0021.factura.model.Factura;
import es.medac.ega0021.factura.model.LineaFactura;
import es.medac.ega0021.factura.model.enums.IVA;

public class GestorFicherosJSON {

    private static final String DIRECTORIO_RAIZ = System.getProperty("user.dir");
    private static final String DIRECTORIO_FACTURAS = DIRECTORIO_RAIZ + File.separator + "data" + File.separator
            + "facturas_json";

    @SuppressWarnings("unchecked")
    public static void guardarFactura(Factura factura) {
        String nombreFichero = "factura_" + factura.getNumeroFactura() + ".json";
        String rutaFichero = DIRECTORIO_FACTURAS + File.separator + nombreFichero;

        JSONObject facturaJSON = new JSONObject();

        // Empresa
        JSONObject empresaJSON = new JSONObject();
        empresaJSON.put("nombre", factura.getEmpresa().getRazonSocial());
        empresaJSON.put("cif", factura.getEmpresa().getCif());
        empresaJSON.put("direccion", factura.getEmpresa().getDireccion());
        empresaJSON.put("telefono", factura.getEmpresa().getTelefono());
        empresaJSON.put("email", factura.getEmpresa().getEmail());

        // Cliente
        JSONObject clienteJSON = new JSONObject();
        clienteJSON.put("nombre", factura.getCliente().getNombre());
        clienteJSON.put("idCliente", factura.getCliente().getId());

        // Líneas de factura
        JSONArray lineasArray = new JSONArray();
        for (LineaFactura linea : factura.getLineasFactura()) {
            JSONObject lineaJSON = new JSONObject();
            lineaJSON.put("articulo", linea.getArticulo());
            lineaJSON.put("cantidad", linea.getCantidad());
            lineaJSON.put("precio", linea.getPrecio());
            lineaJSON.put("iva", linea.getIva().name());
            lineasArray.add(lineaJSON);
        }

        // Construir la factura
        facturaJSON.put("numeroFactura", factura.getNumeroFactura());
        facturaJSON.put("empresa", empresaJSON);
        facturaJSON.put("cliente", clienteJSON);
        facturaJSON.put("lineas", lineasArray);

        try (FileWriter file = new FileWriter(rutaFichero)) {
            file.write(facturaJSON.toJSONString());
            file.flush();
        } catch (IOException e) {
            System.err.println("Error al guardar la factura:");
            e.printStackTrace();
        }
    }

    public static Factura leerFactura(String nombreFichero) {
        String rutaFichero = DIRECTORIO_FACTURAS + File.separator + nombreFichero;

        JSONParser parser = new JSONParser();

        try (FileReader reader = new FileReader(rutaFichero)) {
            JSONObject facturaJSON = (JSONObject) parser.parse(reader);

            // Número de factura
            int numeroFactura = ((Long) facturaJSON.get("numeroFactura")).intValue();

            // Empresa
            JSONObject empresaJSON = (JSONObject) facturaJSON.get("empresa");
            Empresa empresa = new Empresa(
                    (String) empresaJSON.get("nombre"),
                    (String) empresaJSON.get("cif"),
                    (String) empresaJSON.get("direccion"),
                    (String) empresaJSON.get("telefono"),
                    (String) empresaJSON.get("email"));

            // Cliente
            JSONObject clienteJSON = (JSONObject) facturaJSON.get("cliente");
            Cliente cliente = new Cliente(
                    (String) clienteJSON.get("nombre"),
                    (String) clienteJSON.get("idCliente"));

            // Crear Factura
            Factura factura = new Factura();
            factura.setNumeroFactura(numeroFactura);
            factura.setEmpresa(empresa);
            factura.setCliente(cliente);

            // Líneas de factura
            JSONArray lineasArray = (JSONArray) facturaJSON.get("lineas");
            for (Object obj : lineasArray) {
                JSONObject lineaJSON = (JSONObject) obj;

                String articulo = (String) lineaJSON.get("articulo");
                int cantidad = ((Long) lineaJSON.get("cantidad")).intValue();
                double precio = (Double) lineaJSON.get("precio");
                IVA iva = IVA.valueOf((String) lineaJSON.get("iva")); // Recuperamos el enum

                LineaFactura linea = new LineaFactura(articulo, cantidad, precio, iva);
                factura.agregarLinea(linea);
            }

            return factura;

        } catch (Exception e) {
            System.err.println("Error al leer la factura:");
            e.printStackTrace();
            return null;
        }
    }
}
