import java.util.List;
import javax.xml.bind.annotation.*;

@XmlRootElement(name = "facturas")
@XmlAccessorType(XmlAccessType.FIELD)
public class ListaFacturas {
    @XmlElement(name = "factura")
    private List<Factura> facturas;

    public List<Factura> getFacturas() {
        return facturas;
    }

    public void setFacturas(List<Factura> facturas) {
        this.facturas = facturas;
    }
}