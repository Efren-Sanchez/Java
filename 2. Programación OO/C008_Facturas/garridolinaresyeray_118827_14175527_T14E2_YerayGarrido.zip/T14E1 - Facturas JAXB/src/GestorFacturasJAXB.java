import javax.xml.bind.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class GestorFacturasJAXB {
    private static final String FICHERO = "datos/facturas_jaxb.xml";

    public static void guardarFacturasJAXB(Factura[] facturas, int numFacturas) throws JAXBException, IOException {
        new File("datos").mkdir();

        List<Factura> listaFacturas = new ArrayList<>();
        for (int i = 0; i < numFacturas; i++) {
            listaFacturas.add(facturas[i]);
        }

        JAXBContext context = JAXBContext.newInstance(ListaFacturas.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        ListaFacturas wrapper = new ListaFacturas();
        wrapper.setFacturas(listaFacturas);

        try (FileOutputStream fos = new FileOutputStream(FICHERO)) {
            marshaller.marshal(wrapper, fos);
        }
    }

    public static Factura[] cargarFacturasJAXB() throws JAXBException, IOException {
        File fichero = new File(FICHERO);
        if (!fichero.exists()) {
            return null;
        }

        JAXBContext context = JAXBContext.newInstance(ListaFacturas.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();

        try (FileInputStream fis = new FileInputStream(FICHERO)) {
            ListaFacturas wrapper = (ListaFacturas) unmarshaller.unmarshal(fis);
            return wrapper.getFacturas().toArray(new Factura[0]);
        }
    }
}