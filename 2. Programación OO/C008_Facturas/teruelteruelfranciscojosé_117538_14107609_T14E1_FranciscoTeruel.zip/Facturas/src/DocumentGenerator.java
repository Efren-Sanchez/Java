import java.io.PrintWriter;
import java.time.format.DateTimeFormatter;

public class DocumentGenerator {
    static final String BIN_FILE = "facturas.bin";
    static final String XML_FILE = "facturas.xml";

    public static void generarXML() {
        try (PrintWriter pw = new PrintWriter(XML_FILE)) {
            pw.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            pw.println("<facturas>");

            for (Factura f : GestorFacturas.facturas) {
                pw.println("\t<factura>");

                // Detalles de la factura
                pw.println("\t\t<serialVersionUID>" + 1L + "</serialVersionUID>");
                pw.println("\t\t<empresa>" + f.getEmpresa() + "</empresa>");
                pw.println("\t\t<direccionEmpresa>" + f.getDireccionEmpresa() + "</direccionEmpresa>");
                pw.println("\t\t<cifEmpresa>" + f.getCifEmpresa() + "</cifEmpresa>");
                pw.println("\t\t<telefonoEmpresa>" + f.getTelefonoEmpresa() + "</telefonoEmpresa>");
                pw.println("\t\t<emailEmpresa>" + f.getEmailEmpresa() + "</emailEmpresa>");
                pw.println("\t\t<cliente>" + f.getCliente().getNombre() + "</cliente>");
                pw.println("\t\t<nifCliente>" + f.getCliente().getNif() + "</nifCliente>");
                pw.println("\t\t<fechaHora>" + f.getFechaHora().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss")) + "</fechaHora>");
                pw.println("\t\t<numeroFactura>" + f.getNumeroFactura() + "</numeroFactura>");

                // Detalles de las líneas de la factura
                pw.println("\t\t<lineas>");
                for (LineaFactura linea : f.getLineas()) {
                    pw.println("\t\t\t<linea>");
                    pw.println("\t\t\t\t<descripcion>" + linea.getArticulo().getNombre() + "</descripcion>");
                    pw.println("\t\t\t\t<cantidad>" + linea.getCantidad() + "</cantidad>");
                    pw.println("\t\t\t\t<precioUnitario>" + linea.getArticulo().getPrecio() + "</precioUnitario>");
                    pw.println("\t\t\t\t<total>" + linea.getTotalLinea() + "</total>");
                    pw.println("\t\t\t</linea>");
                }
                pw.println("\t\t</lineas>");

                // Total de la factura
                pw.println("\t\t<totalFactura>" + f.getTotalFactura() + "</totalFactura>");

                pw.println("\t</factura>");
            }

            pw.println("</facturas>");
        } catch (Exception e) {
            System.err.println("Error generando XML: " + e.getMessage());
        }
    }
    public static void generarJSON() {
        try (PrintWriter pw = new PrintWriter("facturas.json")) {
            pw.println("[");
            for (int i = 0; i < GestorFacturas.facturas.size(); i++) {
                Factura f = GestorFacturas.facturas.get(i);
                pw.println("  {");
                pw.println("    \"numero\": " + f.getNumero() + ",");
                pw.println("    \"fecha\": \"" + f.getFechaHora()
                        .format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) + "\",");

                // Datos cliente
                pw.println("    \"cliente\": {");
                pw.println("      \"nombre\": \"" + f.getCliente().getNombre() + "\",");
                pw.println("      \"nif\": \"" + f.getCliente().getNif() + "\"");
                pw.println("    },");

                // Líneas de factura
                pw.println("    \"lineas\": [");
                for (int j = 0; j < f.getLineas().size(); j++) {
                    LineaFactura l = f.getLineas().get(j);
                    pw.println("      {");
                    pw.println("        \"articulo\": \"" + l.getArticulo().getNombre() + "\",");
                    pw.println("        \"precio\": " + l.getArticulo().getPrecio()+ ",");
                    pw.println("        \"iva\": \"" + l.getArticulo().getIva() + "\",");
                    pw.println("        \"cantidad\": " + l.getCantidad() + ",");
                    pw.println("        \"total_linea\": " + l.getTotalLinea());
                    pw.print(j < f.getLineas().size()-1 ? "      }," : "      }");
                    pw.println();
                }
                pw.println("    ],");
                pw.println("    \"total\": " + f.getTotal());
                pw.print(i < GestorFacturas.facturas.size()-1 ? "  }," : "  }");
                pw.println();
            }
            pw.println("]");
        } catch (Exception e) {
            System.err.println("Error generando JSON manual: " + e.getMessage());
        }
    }
}
