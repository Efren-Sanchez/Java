import java.io.Serializable;

class Articulo implements Serializable {
    private static final long serialVersionUID = 1L;
    private  String nombre;
    private  double precio;
    private  Iva iva;
    public Articulo(){
        super();
    }
    public Articulo(String nombre,double precio, Iva iva) {
        this.nombre = nombre;
        this.precio = precio;
        this.iva = iva;
    }

    // Getters
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }
    public String getNombre() { return nombre; }
    public double getPrecio() { return precio; }
    public Iva getIva() { return iva; }
}

