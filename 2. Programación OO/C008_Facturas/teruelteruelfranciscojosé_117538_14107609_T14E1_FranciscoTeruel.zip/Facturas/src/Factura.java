import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

class Factura implements Serializable {

    private static final long serialVersionUID = 1L;
    private final String empresa;
    private final String direccionEmpresa;
    private final String cifEmpresa;
    private final String telefonoEmpresa;
    private final String emailEmpresa;
    private final Cliente cliente;
    private final LocalDateTime fechaHora;
    private final int numeroFactura;
    private final List<LineaFactura> lineas;
    private double totalFactura;

    public Factura(String empresa, String direccionEmpresa, String cifEmpresa,
                   String telefonoEmpresa, String emailEmpresa, String cliente,
                   String nifCliente, int numeroFactura) {
        this.empresa = empresa;
        this.direccionEmpresa = direccionEmpresa;
        this.cifEmpresa = cifEmpresa;
        this.telefonoEmpresa = telefonoEmpresa;
        this.emailEmpresa = emailEmpresa;
        this.cliente = new Cliente(cliente,nifCliente);
        this.fechaHora = LocalDateTime.now();
        this.numeroFactura = numeroFactura;
        this.lineas = new ArrayList<>();
        this.totalFactura = 0.0;
    }

    public void agregarLinea(LineaFactura linea) {
        lineas.add(linea);
        totalFactura += linea.getTotalLinea();
    }

    // Getters
    public LocalDateTime getFechaHora() { return fechaHora; }
    public int getNumero() { return numeroFactura; }
    public List<LineaFactura> getLineas() { return lineas; }
    public double getTotal() { return totalFactura; }
    public String getEmpresa() { return empresa; }
    public Cliente getCliente() { return cliente; }

    public double getTotalFactura() {
        return totalFactura;
    }

    public int getNumeroFactura() {
        return numeroFactura;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getCifEmpresa() {
        return cifEmpresa;
    }

    public String getDireccionEmpresa() {
        return direccionEmpresa;
    }

    public String getEmailEmpresa() {
        return emailEmpresa;
    }


    public String getTelefonoEmpresa() {
        return telefonoEmpresa;
    }

    @Override
    public String toString() {
        return "Factura{" +
                "empresa='" + empresa + '\'' +
                ", direccionEmpresa='" + direccionEmpresa + '\'' +
                ", cifEmpresa='" + cifEmpresa + '\'' +
                ", telefonoEmpresa='" + telefonoEmpresa + '\'' +
                ", emailEmpresa='" + emailEmpresa + '\'' +
                ", cliente='" + cliente.getNombre() + '\'' +
                ", nifCliente='" + cliente.getNif() + '\'' +
                ", fechaHora=" + fechaHora +
                ", numeroFactura=" + numeroFactura +
                ", lineas=" + lineas +
                ", totalFactura=" + totalFactura +
                '}';
    }

}
