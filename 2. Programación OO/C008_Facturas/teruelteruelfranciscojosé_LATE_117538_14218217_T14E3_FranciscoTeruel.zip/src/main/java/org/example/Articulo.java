package org.example;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.io.Serializable;
@XmlAccessorType(XmlAccessType.FIELD)
class Articulo implements Serializable {
    private static final long serialVersionUID = 1L;

    @JacksonXmlProperty(localName = "nombre")
    @JsonProperty("nombre")
    private  String nombre;

    @JacksonXmlProperty(localName = "precio")
    @JsonProperty("precio")
    private  double precio;

    @JacksonXmlProperty(localName = "iva")
    @JsonProperty("iva")
    private  Iva iva;
    public Articulo(){
        super();
    }
    public Articulo(String nombre,double precio, Iva iva) {
        this.nombre = nombre;
        this.precio = precio;
        this.iva = iva;
    }

    // Getters
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }
    public String getNombre() { return nombre; }
    public double getPrecio() { return precio; }
    public Iva getIva() { return iva; }
}

