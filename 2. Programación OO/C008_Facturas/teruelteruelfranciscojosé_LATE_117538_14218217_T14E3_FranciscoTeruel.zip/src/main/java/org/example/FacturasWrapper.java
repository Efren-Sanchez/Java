package org.example;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import java.util.List;

@XmlRootElement(name = "facturas")
public class FacturasWrapper {
    private List<Factura> factura;

    @XmlElement(name = "factura")
    public List<Factura> getFacturas() {
        return factura;
    }

    public void setFacturas(List<Factura> factura) {
        this.factura = factura;
    }
}