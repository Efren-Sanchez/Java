package org.example;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class DocumentGeneratorXML {
    public static final String XML_FILE = "facturas.xml";

    public static void generarXML() {
        try {
            JAXBContext context = JAXBContext.newInstance(FacturasWrapper.class);
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

            FacturasWrapper wrapper = new FacturasWrapper();
            wrapper.setFacturas(GestorFacturas.facturas);

            marshaller.marshal(wrapper, new File(XML_FILE));
        } catch (Exception e) {
            System.err.println("Error generando XML: " + e.getMessage());
        }
    }

    public static List<Factura> cargarXML() {
        try {
            JAXBContext context = JAXBContext.newInstance(FacturasWrapper.class);
            Unmarshaller unmarshaller = context.createUnmarshaller();

            FacturasWrapper wrapper = (FacturasWrapper) unmarshaller.unmarshal(new File(XML_FILE));
            return wrapper.getFacturas();

        } catch (Exception e) {
            System.err.println("Error cargando XML: " + e.getMessage());
        }
        return new ArrayList<>();
    }
}