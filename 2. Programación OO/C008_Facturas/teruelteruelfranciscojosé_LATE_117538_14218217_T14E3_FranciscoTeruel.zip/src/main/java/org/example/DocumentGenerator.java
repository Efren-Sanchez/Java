package org.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class DocumentGenerator {
    static final String BIN_FILE = "facturas.bin";

    public static void generarXML() {
     DocumentGeneratorXML.generarXML();
    }
    public static void generarJSON() throws IOException {
        DocumentGeneratorJSON.guardarJSON(GestorFacturas.facturas);
    }
    public static List<Factura> cargarXML(){
         return DocumentGeneratorXML.cargarXML();
    }
    public static List<Factura> cargarJSON() throws IOException {
        return DocumentGeneratorJSON.cargarJSON();
    }
}
