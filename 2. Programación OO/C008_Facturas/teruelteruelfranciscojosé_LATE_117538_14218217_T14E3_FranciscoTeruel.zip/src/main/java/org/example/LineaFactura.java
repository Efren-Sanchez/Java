package org.example;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;


@XmlAccessorType(XmlAccessType.FIELD)
class LineaFactura implements Serializable {

    @JacksonXmlProperty(localName = "articulo")
    private Articulo articulo;

    @JacksonXmlProperty(localName = "cantidad")
    private int cantidad;

    @JacksonXmlProperty(localName = "totalLinea")
    private double totalLinea;

    public LineaFactura(String articulo, int cantidad, double precio, Iva iva) {
        this.articulo = new Articulo(articulo,precio,iva);
        this.cantidad = cantidad;
        calcularTotal();
    }

    private void calcularTotal() {
        totalLinea = cantidad * articulo.getPrecio() * (1 + articulo.getIva().getPorcentaje() / 100.0);
    }

    // Getters
    @JsonProperty("articulo")
    public Articulo getArticulo() { return articulo; }
    public int getCantidad() { return cantidad; }
    public double getTotalLinea() { return totalLinea; }
}
