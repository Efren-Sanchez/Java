import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import org.w3c.dom.*;
import java.io.*;

public class GestorFacturasXML {
    private static final String FICHERO = "datos/facturas.xml";

    public static void guardarFacturasXML(Factura[] facturas, int numFacturas) throws Exception {
        new File("datos").mkdir();
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.newDocument();

        Element root = doc.createElement("facturas");
        doc.appendChild(root);

        for (int i = 0; i < numFacturas; i++) {
            Factura f = facturas[i];
            Element elemFactura = doc.createElement("factura");
            root.appendChild(elemFactura);

            añadirElemento(doc, elemFactura, "numero", String.valueOf(f.getNumeroFactura()));
            añadirElemento(doc, elemFactura, "fecha", f.getFechaHora().toString());

            Element elemCliente = doc.createElement("cliente");
            elemFactura.appendChild(elemCliente);
            añadirElemento(doc, elemCliente, "nombre", f.getNombreCliente());
            añadirElemento(doc, elemCliente, "nif", f.getNifCliente());

            Element elemLineas = doc.createElement("lineas");
            elemFactura.appendChild(elemLineas);

            for (int j = 0; j < f.getNumLineas(); j++) {
                LineaFactura linea = f.getLineas()[j];
                Element elemLinea = doc.createElement("linea");
                elemLineas.appendChild(elemLinea);

                añadirElemento(doc, elemLinea, "articulo", linea.getArticulo());
                añadirElemento(doc, elemLinea, "cantidad", String.valueOf(linea.getCantidad()));
                añadirElemento(doc, elemLinea, "precio", String.valueOf(linea.getPrecio()));
                añadirElemento(doc, elemLinea, "iva", linea.getIva().name());
                añadirElemento(doc, elemLinea, "total", String.valueOf(linea.getTotal()));
            }

            añadirElemento(doc, elemFactura, "totalFactura", String.valueOf(f.getTotal()));
        }

        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.transform(new DOMSource(doc), new StreamResult(new File(FICHERO)));
    }

    // Método auxiliar para añadir un elemento al documento XML
    private static void añadirElemento(Document doc, Element padre, String nombre, String valor) {
        Element elem = doc.createElement(nombre);
        elem.appendChild(doc.createTextNode(valor));
        padre.appendChild(elem);
    }
}