import java.util.Scanner;

public class UtilidadesFactura {
    private static final Scanner sc = new Scanner(System.in);

    // Método para leer un String
    public static String leerString(String mensaje) {
        System.out.print(mensaje);
        return sc.nextLine();
    }

    // Método para leer un entero con validación de datos
    public static int leerInt(String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                return Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Error: Introduce un número entero válido.");
            }
        }
    }

    // Método para leer un double con validación de datos
    public static double leerDouble(String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                return Double.parseDouble(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Error: Introduce un número válido (ej. 15.99).");
            }
        }
    }

    // Método para limpiar la pantalla de la consola
    public static void limpiarPantalla() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }
}