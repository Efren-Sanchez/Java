import java.io.*;
import java.time.LocalDateTime;

public class GestorFacturasBinario {
    private static final String FICHERO = "datos/facturas.dat";

    public static void guardarFacturas(Factura[] facturas, int numFacturas) throws IOException {
        new File("datos").mkdir();
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(FICHERO))) {
            dos.writeInt(numFacturas);
            for (int i = 0; i < numFacturas; i++) {
                Factura f = facturas[i];
                dos.writeInt(f.getNumeroFactura());
                dos.writeUTF(f.getNombreCliente());
                dos.writeUTF(f.getNifCliente());
                dos.writeUTF(f.getFechaHora().toString());
                dos.writeInt(f.getNumLineas());
                for (int j = 0; j < f.getNumLineas(); j++) {
                    LineaFactura linea = f.getLineas()[j];
                    dos.writeUTF(linea.getArticulo());
                    dos.writeInt(linea.getCantidad());
                    dos.writeDouble(linea.getPrecio());
                    dos.writeUTF(linea.getIva().name());
                }
                dos.writeDouble(f.getTotal());
            }
        }
    }

    // Carga las facturas desde el fichero binario
    // Devuelve un array de facturas o null si no hay facturas
    public static Factura[] cargarFacturas() throws IOException {
        File fichero = new File(FICHERO);
        if (!fichero.exists())
            return null;

        try (DataInputStream dis = new DataInputStream(new FileInputStream(FICHERO))) {
            int numFacturas = dis.readInt();
            Factura[] facturas = new Factura[numFacturas];
            for (int i = 0; i < numFacturas; i++) {
                int numero = dis.readInt();
                String nombre = dis.readUTF();
                String nif = dis.readUTF();
                LocalDateTime fecha = LocalDateTime.parse(dis.readUTF());
                int numLineas = dis.readInt();
                Factura factura = new Factura(nombre, nif, numero);
                factura.setFechaHora(fecha);
                for (int j = 0; j < numLineas; j++) {
                    factura.añadirLinea(new LineaFactura(
                            dis.readUTF(),
                            dis.readInt(),
                            dis.readDouble(),
                            TipoIVA.valueOf(dis.readUTF())));
                }
                factura.setTotal(dis.readDouble());
                facturas[i] = factura;
            }
            return facturas;
        }
    }
}