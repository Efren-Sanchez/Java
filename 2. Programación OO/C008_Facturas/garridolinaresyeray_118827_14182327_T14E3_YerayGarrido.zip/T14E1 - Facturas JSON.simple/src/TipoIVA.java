public enum TipoIVA {
    SUPER_REDUCIDO(0.04),
    REDUCIDO(0.10),
    NORMAL(0.21);

    private final double porcentaje;

    TipoIVA(double porcentaje) {
        this.porcentaje = porcentaje;
    }

    public double getPorcentaje() {
        return porcentaje;
    }
}