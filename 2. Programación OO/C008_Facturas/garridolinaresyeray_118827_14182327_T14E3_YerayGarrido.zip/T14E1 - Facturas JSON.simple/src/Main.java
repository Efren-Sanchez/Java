import java.io.IOException;

public class Main {
    private static Factura[] facturas = new Factura[10];
    private static int numFacturas = 0;
    private static int siguienteNumeroFactura = 1;

    public static void main(String[] args) {
        cargarDatosIniciales();

        boolean salir = false;
        while (!salir) {
            mostrarMenu();
            int opcion = UtilidadesFactura.leerInt("Selecciona una opción: ");

            switch (opcion) {
                case 1:
                    crearFactura();
                    break;
                case 2:
                    mostrarFacturas();
                    break;
                case 3:
                    guardarXML();
                    break;
                case 4:
                    guardarJAXB();
                    break;
                case 5:
                    guardarJSON();
                    break;
                case 6:
                    guardarBinario();
                    break;
                case 7:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción no válida (1-7).");
            }
        }

        guardarBinario();
        System.out.println("Programa finalizado.");
    }

    // Método para cargar datos iniciales desde un archivo binario
    private static void cargarDatosIniciales() {
        try {
            Factura[] cargadas = GestorFacturasBinario.cargarFacturas();
            if (cargadas != null) {
                facturas = cargadas;
                numFacturas = cargadas.length;
                if (numFacturas > 0) {
                    siguienteNumeroFactura = facturas[numFacturas - 1].getNumeroFactura() + 1;
                }
            }
        } catch (Exception e) {
            System.out.println("No se cargaron facturas binarias previas.");
        }
    }

    // Método para mostrar el menú principal
    private static void mostrarMenu() {
        UtilidadesFactura.limpiarPantalla();
        System.out.println("\n--- MENÚ PRINCIPAL ---");
        System.out.println("1. Crear factura");
        System.out.println("2. Mostrar facturas");
        System.out.println("3. Guardar XML (DOM)");
        System.out.println("4. Guardar XML (JAXB)");
        System.out.println("5. Guardar JSON");
        System.out.println("6. Guardar binario");
        System.out.println("7. Salir");
    }

    // Método para crear una nueva factura
    private static void crearFactura() {
        UtilidadesFactura.limpiarPantalla();
        String nombre = UtilidadesFactura.leerString("Nombre cliente: ");
        String nif = UtilidadesFactura.leerString("NIF cliente: ");
        Factura factura = new Factura(nombre, nif, siguienteNumeroFactura++);

        boolean continuar = true;
        while (continuar) {
            String articulo = UtilidadesFactura.leerString("Artículo: ");
            int cantidad = UtilidadesFactura.leerInt("Cantidad: ");
            double precio = UtilidadesFactura.leerDouble("Precio: ");

            System.out.println("Tipo IVA:\n1. Superreducido (4%)\n2. Reducido (10%)\n3. Normal (21%)");
            TipoIVA iva = switch (UtilidadesFactura.leerInt("Opción: ")) {
                case 1 -> TipoIVA.SUPER_REDUCIDO;
                case 2 -> TipoIVA.REDUCIDO;
                default -> TipoIVA.NORMAL;
            };

            factura.añadirLinea(new LineaFactura(articulo, cantidad, precio, iva));
            continuar = UtilidadesFactura.leerString("¿Añadir otra línea? (s/n): ").equalsIgnoreCase("s");
        }

        if (numFacturas == facturas.length) {
            Factura[] nuevo = new Factura[facturas.length * 2];
            System.arraycopy(facturas, 0, nuevo, 0, facturas.length);
            facturas = nuevo;
        }
        facturas[numFacturas++] = factura;
        System.out.println("Factura creada:\n" + factura);
        UtilidadesFactura.leerString("Presiona Enter...");
    }

    // Método para mostrar todas las facturas
    private static void mostrarFacturas() {
        UtilidadesFactura.limpiarPantalla();
        if (numFacturas == 0) {
            System.out.println("No hay facturas registradas.");
        } else {
            for (int i = 0; i < numFacturas; i++) {
                System.out.println(facturas[i] + "\n----------");
            }
        }
        UtilidadesFactura.leerString("Presiona Enter...");
    }

    // Metodo para guardar las facturas en formato XML (DOM)
    private static void guardarXML() {
        try {
            GestorFacturasXML.guardarFacturasXML(facturas, numFacturas);
            System.out.println("XML (DOM) guardado correctamente.");
        } catch (Exception e) {
            System.out.println("Error al guardar XML (DOM): " + e.getMessage());
        }
        UtilidadesFactura.leerString("Presiona Enter...");
    }

    // Método para guardar las facturas en formato JAXB
    private static void guardarJAXB() {
        try {
            GestorFacturasJAXB.guardarFacturasJAXB(facturas, numFacturas);
            System.out.println("XML (JAXB) guardado correctamente.");
        } catch (Exception e) {
            System.out.println("Error al guardar XML (JAXB): " + e.getMessage());
        }
        UtilidadesFactura.leerString("Presiona Enter...");
    }

    // Método para guardar las facturas en formato JSON
    private static void guardarJSON() {
        try {
            GestorFacturasJSON.guardarFacturasJSON(facturas, numFacturas);
            System.out.println("JSON guardado correctamente.");
        } catch (Exception e) {
            System.out.println("Error al guardar JSON: " + e.getMessage());
        }
        UtilidadesFactura.leerString("Presiona Enter...");
    }

    // Método para guardar las facturas en formato binario
    private static void guardarBinario() {
        try {
            GestorFacturasBinario.guardarFacturas(facturas, numFacturas);
            System.out.println("Facturas guardadas en formato binario exitosamente.");
        } catch (IOException e) {
            System.out.println("Error al guardar en formato binario: " + e.getMessage());
        }
        UtilidadesFactura.leerString("\nPulsa la tecla Enter para continuar...");
    }
}
