import java.time.LocalDateTime;
import javax.xml.bind.annotation.*;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
public class Factura {
    public static final String NOMBRE_EMPRESA = "SuperWebinars S.L.";
    public static final String DIRECCION = "C/ La Paz, 123";
    public static final String CIF = "B12345678";
    public static final String TELEFONO = "964123456";
    public static final String EMAIL = "info@superwebinars.com";

    @XmlElement
    private String nombreCliente;
    @XmlElement
    private String nifCliente;
    @XmlElement
    @XmlJavaTypeAdapter(LocalDateTimeAdapter.class)
    private LocalDateTime fechaHora;
    @XmlElement
    private int numeroFactura;
    @XmlElementWrapper(name = "lineas")
    @XmlElement(name = "linea")
    private LineaFactura[] lineas;
    @XmlTransient
    private int numLineas;
    @XmlElement
    private double total;

    public Factura() {
        this("", "", 0);
    }

    public Factura(String nombreCliente, String nifCliente, int numeroFactura) {
        this.nombreCliente = nombreCliente;
        this.nifCliente = nifCliente;
        this.numeroFactura = numeroFactura;
        this.fechaHora = LocalDateTime.now();
        this.lineas = new LineaFactura[10];
        this.numLineas = 0;
        this.total = 0.0;
    }

    public Factura(Factura factura) {
        this.nombreCliente = factura.nombreCliente;
        this.nifCliente = factura.nifCliente;
        this.numeroFactura = factura.numeroFactura;
        this.fechaHora = factura.fechaHora;
        this.lineas = new LineaFactura[factura.lineas.length];
        System.arraycopy(factura.lineas, 0, this.lineas, 0, factura.numLineas);
        this.numLineas = factura.numLineas;
        this.total = factura.total;
    }

    public void añadirLinea(LineaFactura linea) {
        if (numLineas == lineas.length) {
            LineaFactura[] nuevo = new LineaFactura[lineas.length * 2];
            System.arraycopy(lineas, 0, nuevo, 0, lineas.length);
            lineas = nuevo;
        }
        lineas[numLineas++] = linea;
        total += linea.getTotal();
    }

    public int getNumeroFactura() {
        return numeroFactura;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public String getNifCliente() {
        return nifCliente;
    }

    public LocalDateTime getFechaHora() {
        return fechaHora;
    }

    public LineaFactura[] getLineas() {
        return lineas;
    }

    public int getNumLineas() {
        return numLineas;
    }

    public double getTotal() {
        return total;
    }

    public void setFechaHora(LocalDateTime fechaHora) {
        this.fechaHora = fechaHora;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("FACTURA Nº: ").append(numeroFactura).append("\n");
        sb.append("Fecha: ").append(fechaHora).append("\n\n");
        sb.append("EMPRESA: ").append(NOMBRE_EMPRESA).append("\n");
        sb.append("CLIENTE: ").append(nombreCliente).append(" - NIF: ").append(nifCliente).append("\n\n");
        sb.append(String.format("%-20s %5s %10s %10s %10s", "ARTÍCULO", "CANT", "PRECIO", "IVA", "TOTAL")).append("\n");

        for (int i = 0; i < numLineas; i++) {
            sb.append(lineas[i].toString()).append("\n");
        }

        sb.append("\nTOTAL FACTURA: ").append(String.format("%.2f", total)).append(" €");
        return sb.toString();
    }
}