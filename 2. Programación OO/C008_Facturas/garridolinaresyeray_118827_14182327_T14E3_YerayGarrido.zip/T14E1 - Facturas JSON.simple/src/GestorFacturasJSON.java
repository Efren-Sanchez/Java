import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.io.*;
import java.time.format.DateTimeFormatter;

@SuppressWarnings("unchecked") // Para suprimir advertencias de tipo unchecked
// Clase para gestionar la lectura y escritura de facturas en formato JSON
public class GestorFacturasJSON {
    private static final String FICHERO = "datos/facturas.json";

    public static void guardarFacturasJSON(Factura[] facturas, int numFacturas) throws IOException {
        new File("datos").mkdir();

        JSONArray jsonFacturas = new JSONArray();

        for (int i = 0; i < numFacturas; i++) {
            Factura f = facturas[i];
            JSONObject jsonFactura = new JSONObject();

            jsonFactura.put("numero", f.getNumeroFactura());
            jsonFactura.put("fecha", f.getFechaHora().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
            jsonFactura.put("nombreCliente", f.getNombreCliente());
            jsonFactura.put("nifCliente", f.getNifCliente());

            JSONArray jsonLineas = new JSONArray();
            for (int j = 0; j < f.getNumLineas(); j++) {
                LineaFactura linea = f.getLineas()[j];
                JSONObject jsonLinea = new JSONObject();

                jsonLinea.put("articulo", linea.getArticulo());
                jsonLinea.put("cantidad", linea.getCantidad());
                jsonLinea.put("precio", linea.getPrecio());
                jsonLinea.put("iva", linea.getIva().name());
                jsonLinea.put("totalLinea", linea.getTotal());

                jsonLineas.add(jsonLinea);
            }
            jsonFactura.put("lineas", jsonLineas);
            jsonFactura.put("totalFactura", f.getTotal());

            jsonFacturas.add(jsonFactura);
        }

        try (FileWriter file = new FileWriter(FICHERO)) {
            file.write(jsonFacturas.toJSONString());
            file.flush();
        }
    }

    // Método para cargar las facturas desde un archivo JSON
    public static Factura[] cargarFacturasJSON() throws IOException, ParseException {
        File fichero = new File(FICHERO);
        if (!fichero.exists()) {
            return null;
        }

        JSONParser parser = new JSONParser();

        try (FileReader reader = new FileReader(FICHERO)) {
            JSONArray jsonFacturas = (JSONArray) parser.parse(reader);
            Factura[] facturas = new Factura[jsonFacturas.size()];

            for (int i = 0; i < jsonFacturas.size(); i++) {
                JSONObject jsonFactura = (JSONObject) jsonFacturas.get(i);

                String nombreCliente = (String) jsonFactura.get("nombreCliente");
                String nifCliente = (String) jsonFactura.get("nifCliente");
                int numero = ((Long) jsonFactura.get("numero")).intValue();

                Factura factura = new Factura(nombreCliente, nifCliente, numero);
                factura.setFechaHora(java.time.LocalDateTime.parse((String) jsonFactura.get("fecha")));

                JSONArray jsonLineas = (JSONArray) jsonFactura.get("lineas");
                for (Object obj : jsonLineas) {
                    JSONObject jsonLinea = (JSONObject) obj;

                    String articulo = (String) jsonLinea.get("articulo");
                    int cantidad = ((Long) jsonLinea.get("cantidad")).intValue();
                    double precio = (double) jsonLinea.get("precio");
                    TipoIVA iva = TipoIVA.valueOf((String) jsonLinea.get("iva"));

                    factura.añadirLinea(new LineaFactura(articulo, cantidad, precio, iva));
                }

                factura.setTotal((double) jsonFactura.get("totalFactura"));
                facturas[i] = factura;
            }

            return facturas;
        }
    }
}