import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class LineaFactura {
    @XmlElement
    private String articulo;
    @XmlElement
    private int cantidad;
    @XmlElement
    private double precio;
    @XmlElement
    private TipoIVA iva;
    @XmlElement
    private double total;

    public LineaFactura() {
        this("", 0, 0.0, TipoIVA.NORMAL);
    }

    public LineaFactura(String articulo, int cantidad, double precio, TipoIVA iva) {
        this.articulo = articulo;
        this.cantidad = cantidad;
        this.precio = precio;
        this.iva = iva;
        this.total = cantidad * precio * (1 + iva.getPorcentaje());
    }

    public LineaFactura(LineaFactura linea) {
        this.articulo = linea.articulo;
        this.cantidad = linea.cantidad;
        this.precio = linea.precio;
        this.iva = linea.iva;
        this.total = linea.total;
    }

    public String getArticulo() {
        return articulo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public double getPrecio() {
        return precio;
    }

    public TipoIVA getIva() {
        return iva;
    }

    public double getTotal() {
        return total;
    }

    @Override
    public String toString() {
        return String.format("%-20s %5d %10.2f %10s %10.2f",
                articulo, cantidad, precio, iva, total);
    }
}