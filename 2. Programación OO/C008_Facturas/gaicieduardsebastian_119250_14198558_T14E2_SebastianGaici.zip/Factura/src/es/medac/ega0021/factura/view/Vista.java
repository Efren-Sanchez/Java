package es.medac.ega0021.factura.view;

import java.util.Scanner;

import es.medac.ega0021.factura.App;
import es.medac.ega0021.factura.model.Cliente;
import es.medac.ega0021.factura.model.Factura;
import es.medac.ega0021.factura.model.LineaFactura;
import es.medac.ega0021.factura.model.enums.IVA;

public final class Vista {

    private final Scanner scanner = new Scanner(System.in);

    /***** PANTALLAS PRINCIPALES *****/
    public String mostrarPantallaInicio() {
        String entrada;

        while (true) {
            System.out.println(Componentes.SEPARADOR_BLOQUE);
            Componentes.nombreBloque("PROGRAMA DE FACTURACION");
            System.out.println(Componentes.SEPARADOR_BLOQUE);
            System.out.println();

            System.out.println("Bienvenido/a al Programa de Facturación.\n");
            System.out.println("Con esta aplicación podrá gestionar sus facturas de manera");
            System.out.println("rápida y sencilla.\n");
            System.out.println("Para una mejor experiencia, se recomienda utilizar la aplicación");
            System.out.println("en pantalla completa.\n");
            System.out.printf("Creado por %s\n", App.AUTOR);
            System.out.println();

            System.out.println(Componentes.SEPARADOR_CONTENIDO);

            System.out.printf("Escriba %screar%s para crear una nueva factura.\n",
                    Componentes.ANSI_AMARILLO, Componentes.ANSI_RESET);
            System.out.printf("Escriba %sver%s para consultar una factura guardada.\n",
                    Componentes.ANSI_AMARILLO, Componentes.ANSI_RESET);
            System.out.printf("Escriba %ssalir%s para salir de la aplicación.\n",
                    Componentes.ANSI_AMARILLO, Componentes.ANSI_RESET);

            System.out.println(Componentes.SEPARADOR_CONTENIDO);
            System.out.print("> ");

            entrada = scanner.nextLine().trim().toLowerCase();
            Componentes.limpiarConsola();

            if (entrada.equals("crear") || entrada.equals("ver") || entrada.equals("salir")) {
                return entrada;
            }
        }
    }

    public int mostrarSelectorFacturas(Factura[] facturas) {

        while (true) {

            System.out.println(Componentes.SEPARADOR_BLOQUE);
            Componentes.nombreBloque("PREVIEW DE FACTURAS");
            System.out.println(Componentes.SEPARADOR_BLOQUE);
            System.out.println();
            System.out.println("Bienvenido al selector de facturas.");
            System.out.println("Aquí puedes consultar todas las facturas almacenadas en el sistema.");
            System.out.println("Introduce el número de la factura que deseas visualizar.");
            System.out.println();
            System.out.println(Componentes.SEPARADOR_CONTENIDO);
            System.out.println();

            final String separador = "+------------+----------------------------+---------------------+";
            final String encabezado = "|   Número   |           Cliente          |        Fecha        |";

            System.out.println(separador);
            System.out.println(encabezado);
            System.out.println(separador);

            for (Factura factura : facturas) {
                System.out.printf(
                        "| %-10d | %-26s | %-19s |\n",
                        factura.getNumeroFactura(),
                        factura.getCliente().getNombre(),
                        Componentes.FORMATO_FECHA_CORTA.format(factura.getFechaEmision()));
            }

            System.out.println(separador);
            System.out.println();
            System.out.println(Componentes.SEPARADOR_CONTENIDO);
            System.out.println();

            System.out.print("> ");
            byte entrada = scanner.nextByte();
            Componentes.limpiarConsola();

            if (!(entrada < 0 || entrada > facturas.length)) {
                return entrada;
            }
        }
    }

    public void mostrarFactura(Factura factura) {
        // Enzabezado principal
        System.out.println(Componentes.SEPARADOR_BLOQUE);
        Componentes.nombreBloque("FACTURA Nº " + factura.getNumeroFactura());
        System.out.println(Componentes.SEPARADOR_BLOQUE);
        System.out.println();

        System.out.printf("Fecha de emisión: %s\tUsuario: @%s\n",
                Componentes.FORMATO_FECHA_COMPLETA.format(factura.getFechaEmision()),
                System.getProperty("user.name"));

        System.out.println();
        System.out.println(Componentes.SEPARADOR_CONTENIDO);
        System.out.println();

        // Empresa
        System.out.println(factura.getEmpresa().getRazonSocial());
        System.out.println(factura.getEmpresa().getCif());
        System.out.println(factura.getEmpresa().getDireccion());
        System.out.println(factura.getEmpresa().getTelefono());
        System.out.println(factura.getEmpresa().getEmail());

        System.out.println();
        System.out.println(Componentes.SEPARADOR_CONTENIDO);
        System.out.println();

        // Cliente
        System.out.printf("Nombre: %s\n", factura.getCliente().getNombre());
        System.out.printf("ID cliente: %s\n", factura.getCliente().getId());

        System.out.println();
        System.out.println(Componentes.SEPARADOR_CONTENIDO);
        System.out.println();

        // Lineas de factura
        Componentes.encabezadoTablaFactura();
        for (LineaFactura lineaFactura : factura.getLineasFactura()) {
            if (lineaFactura == null)
                continue;
            System.out.print(String.format(
                    "| %-12s | %9dx | %9.2f E | %9.2f E | %3d %% |%n",
                    lineaFactura.getArticulo(),
                    lineaFactura.getCantidad(),
                    lineaFactura.getPrecio(),
                    lineaFactura.calcularSubtotal(),
                    lineaFactura.getIva().getPorcentaje()));
        }
        System.out.println(Componentes.PIE_TABLA_FACTURA);

        System.out.println();

        // Totales
        System.out.println(String.format(Componentes.PATRON_TOTAL, "SUBTOTAL", factura.calcularBaseImponible()));
        System.out.println(String.format(Componentes.PATRON_TOTAL, "TOTAL IVA", factura.calcularIVA()));
        System.out.println(String.format(Componentes.PATRON_TOTAL, "TOTAL FACTURA", factura.calcularTotal()));
    }

    public void mostrarConfirmacionGuardado(Factura factura) {
        System.out.println();
        System.out.println(Componentes.SEPARADOR_CONTENIDO);
        System.out.println();

        String nombreArchivo = "factura_" + factura.getNumeroFactura() + ".xml";
        System.out.printf("%s ha sido guardado con éxito.\n", nombreArchivo);

        System.out.println();
        System.out.println(Componentes.SEPARADOR_CONTENIDO);
        System.out.println();
    }

    public void introducirDatosCliente(Factura factura) {
        String nombre;
        String id;

        while (true) {
            mostrarEncabezadoFactura(factura);

            System.out.println(Componentes.SEPARADOR_BLOQUE);
            Componentes.nombreBloque("DATOS DEL CLIENTE");
            System.out.println(Componentes.SEPARADOR_BLOQUE);
            System.out.println();

            System.out.print("[1/2] Nombre del cliente: ");
            nombre = scanner.nextLine().trim();
            System.out.println();

            System.out.print("[2/2] Número de identificación: ");
            id = scanner.nextLine().trim();
            System.out.println();

            System.out.println(Componentes.SEPARADOR_CONTENIDO);
            System.out.println();

            boolean confirmado = confirmarEntradaUsuario(Componentes.PREGUNTA_DATOS_CORRECTOS);
            System.out.printf("%n%s%n", Componentes.SEPARADOR_CONTENIDO);

            if (confirmado) {
                System.out.print("\n¡Datos registrados! Pulse ENTER para continuar...");
                scanner.nextLine();
                Componentes.limpiarConsola();
                break;
            } else {
                System.out.print(Componentes.MENSAJE_REINTRODUCIR_DATOS);
                scanner.nextLine();
                Componentes.limpiarConsola();
            }
        }

        factura.setCliente(new Cliente(nombre, id));
    }

    public void introducirLineasFactura(Factura factura) {
        while (true) {
            int siguienteNumeroLinea = factura.getcontadorLineas() + 1;
            LineaFactura nuevaLinea = introducirLineaFactura(factura, siguienteNumeroLinea);
            factura.agregarLinea(nuevaLinea);

            System.out.printf("%n%s%n%n", Componentes.SEPARADOR_CONTENIDO);

            boolean continuar = confirmarEntradaUsuario(Componentes.PREGUNTA_NUEVA_LINEA);
            Componentes.limpiarConsola();

            if (!continuar)
                break;
        }
    }

    private LineaFactura introducirLineaFactura(Factura factura, int numeroLinea) {
        String articulo;
        int cantidad;
        double precio;
        IVA iva = null;
        String entradaIVA;

        while (true) {
            mostrarEncabezadoFactura(factura);

            System.out.println(Componentes.SEPARADOR_BLOQUE);
            Componentes.nombreBloque("LINEA " + numeroLinea);
            System.out.println(Componentes.SEPARADOR_BLOQUE);
            System.out.println();

            System.out.print("[1/4] Nombre del artículo: ");
            articulo = scanner.nextLine().trim();
            System.out.println();

            System.out.print("[2/4] Cantidad a comprar: ");
            cantidad = Integer.parseInt(scanner.nextLine().trim());
            System.out.println();

            System.out.print("[3/4] Precio unitario (euros): ");
            precio = Double.parseDouble(scanner.nextLine().trim());
            System.out.println();

            // Seleccionar el IVA
            while (true) {
                System.out.print("[4/4] Tipo de IVA (s/r/n): ");
                entradaIVA = scanner.nextLine().trim().toLowerCase();

                if (entradaIVA.isEmpty())
                    System.out.println(Componentes.ERROR_PREGUNTA_SIN_RESPUESTA);
                else if (!entradaIVA.matches("[srn]"))
                    System.out.println(Componentes.ERROR_CARACTER_INCORRECTO);
                else
                    break;
            }

            switch (entradaIVA.charAt(0)) {
                case 's' -> iva = IVA.SUPER_REDUCIDO;
                case 'r' -> iva = IVA.REDUCIDO;
                case 'n' -> iva = IVA.NORMAL;
            }

            // Vista previa
            double subtotal = cantidad * precio;
            byte porcentajeIVA = (byte) iva.getPorcentaje();

            System.out.printf("%n%s%n%n", Componentes.SEPARADOR_CONTENIDO);
            Componentes.encabezadoTablaFactura();
            System.out.printf(
                    "| %-12s | %9dx | %9.2f E | %9.2f E | %3d %% |%n",
                    articulo, cantidad, precio, subtotal, porcentajeIVA);
            System.out.println(Componentes.PIE_TABLA_FACTURA);
            System.out.printf("%n%s%n%n", Componentes.SEPARADOR_CONTENIDO);

            if (confirmarEntradaUsuario(Componentes.PREGUNTA_DATOS_CORRECTOS)) {
                return new LineaFactura(articulo, cantidad, precio, iva);
            }

            System.out.printf("%n%s%n", Componentes.SEPARADOR_CONTENIDO);
            System.out.print(Componentes.MENSAJE_REINTRODUCIR_DATOS);
            scanner.nextLine();
            Componentes.limpiarConsola();
        }
    }

    /***** MÉTODOS AUXILIARES *****/
    private void mostrarEncabezadoFactura(Factura factura) {
        System.out.println(Componentes.SEPARADOR_BLOQUE);
        Componentes.nombreBloque("FACTURA");
        System.out.println(Componentes.SEPARADOR_BLOQUE);
        System.out.println();

        System.out.printf("Factura Nº: %-10d\tFecha: %s\t@%s\n",
                factura.getNumeroFactura(),
                Componentes.FORMATO_FECHA_CORTA.format(factura.getFechaEmision()),
                System.getProperty("user.name"));

        System.out.println();
    }

    private boolean confirmarEntradaUsuario(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String entrada = scanner.nextLine().trim().toLowerCase();

            if (entrada.isEmpty()) {
                System.out.println(Componentes.ERROR_PREGUNTA_SIN_RESPUESTA);
            } else {
                char opcion = entrada.charAt(0);
                switch (opcion) {
                    case 's' -> {
                        return true;
                    }
                    case 'n' -> {
                        return false;
                    }
                    default -> System.out.println(Componentes.ERROR_CARACTER_INCORRECTO);
                }
            }
        }
    }
}