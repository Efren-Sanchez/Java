package es.medac.ega0021.factura.model;

public class Empresa {

     /***** Atributos *****/
    private String razonSocial;
    private String cif;
    private String direccion;
    private String telefono;
    private String email;

    /***** Constructores *****/
    public Empresa() {
        this.razonSocial = "";
        this.cif = "";
        this.direccion = "";
        this.telefono = "";
        this.email = "";
    }

    public Empresa(String razonSocial, String cif, String direccion, String telefono, String email) {
        this.razonSocial = razonSocial;
        this.cif = cif;
        this.direccion = direccion;
        this.telefono = telefono;
        this.email = email;
    }

    public Empresa(Empresa e) {
        this.razonSocial = e.razonSocial;
        this.cif = e.cif;
        this.direccion = e.direccion;
        this.telefono = e.telefono;
        this.email = e.email;
    }

    /***** Getters y Setters *****/
    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    /***** Métodos comunes *****/
    @Override
    public String toString() {
        return String.format("""
                Razón Social: %s
                CIF: %s
                Dirección: %s
                Teléfono: %s
                Email: %s""",
                razonSocial,
                cif,
                direccion,
                telefono,
                email);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) 
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        
        Empresa objConvertido = (Empresa) obj;

        return this.razonSocial == objConvertido.razonSocial &&
                this.cif == objConvertido.cif &&
                this.direccion == objConvertido.direccion &&
                this.telefono == objConvertido.telefono &&
                this.email == objConvertido.email;
    }
}