package es.medac.ega0021.factura;

import jakarta.xml.bind.JAXBException;

import es.medac.ega0021.factura.model.Cliente;
import es.medac.ega0021.factura.model.Empresa;
import es.medac.ega0021.factura.model.Factura;
import es.medac.ega0021.factura.model.LineaFactura;
import es.medac.ega0021.factura.model.enums.IVA;
import es.medac.ega0021.factura.util.GestorFicherosJAXB;
import es.medac.ega0021.factura.util.GestorFicherosXML;
import es.medac.ega0021.factura.view.Vista;

public class App {

    public static final String AUTOR = "ega0021@alu.medac.es";

    static Vista vista;
    static Empresa empresa;
    static Factura[] facturas;

    public static void main(String[] args) throws JAXBException {

        // 👁️: He comentado el código anterior para que sea más fácil jugar con las
        // nuevas funciones de JAXB.
        // Para más información, he creado un pequeño documento README.txt

        /*
         * vista = new Vista();
         * empresa = new Empresa(
         * "El Corte Inglés S.A.",
         * "A28017895",
         * "Calle Hermosilla 112, 28009 Madrid, España",
         * "914 018 500",
         * "clientes@elcorteingles.es");
         * facturas = GestorFicherosXML.cargarFacturas();
         * 
         * // Mostrar la pantalla de inicio y ejecutar la opción elegida
         * switch (vista.mostrarPantallaInicio()) {
         * case "crear" -> crearFactura();
         * case "ver" -> verFactura();
         * case "salir" -> System.exit(0);
         * }
         */

        // 👁️: El método guardarFactura(), guardará la factura que se le pase
        // automáticamente en la carpeta `/data/facturas_jaxb`

        // 👁️: El método leerFactura() está pensado para pasarle una factura mediante
        // un fichero XML (File) y construir un objeto Factura a partir de ella.
        // Pero, para simplificar las pruebas aquí en el main(), he sobrecargado el
        // método pudiendo pasarle solamente el nombre de la factura que se desee leer y
        // el método se encarga del resto.

        // 👁️: Para crear la factura de abajo, no he utilizado el constructor completo
        // con todos los parámetros porque hay un error de cuentas al contar las lineas
        // de la factura sin hacer uso del método agregarLinea. Podría haber solucionado
        // el error o creado un constructor al que se le pase todo excepto las líneas de
        // factura, pero bueno, no lo hice...      

        Factura factura = new Factura();
        empresa = new Empresa(
                "El Corte Inglés S.A.",
                "A28017895",
                "Calle Hermosilla 112, 28009 Madrid, España",
                "914 018 500",
                "clientes@elcorteingles.es");
        Cliente cliente = new Cliente("Eduard Sebastian Gaici", "A12345678");
        LineaFactura lF1 = new LineaFactura("Gazpacho", 2, 2.57, IVA.NORMAL);
        LineaFactura lF2 = new LineaFactura("Picatostes", 2, 0.75, IVA.NORMAL);
        factura.setEmpresa(empresa);
        factura.setCliente(cliente);
        factura.agregarLinea(lF1);
        factura.agregarLinea(lF2);

        
        GestorFicherosJAXB.guardarFactura(factura);

        Factura f = GestorFicherosJAXB.leerFactura("factura_1.xml");
        System.out.println(f);

    }

    public static void crearFactura() {
        Factura factura = new Factura(empresa);

        vista.introducirDatosCliente(factura);
        vista.introducirLineasFactura(factura);
        vista.mostrarFactura(factura);

        GestorFicherosXML.guardarFactura(factura);
        vista.mostrarConfirmacionGuardado(factura);
    }

    public static void verFactura() {
        if (facturas.length == 0) {
            System.out.println("No hay facturas guardadas. Pulse ENTER para salir.");
            System.exit(0);
        }
        Factura facturaElegida = facturas[vista.mostrarSelectorFacturas(facturas) - 1];
        facturaElegida.setEmpresa(empresa);
        vista.mostrarFactura(facturaElegida);
    }
}