package es.medac.ega0021.factura.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import es.medac.ega0021.factura.model.Factura;

final class GestorFicherosBinario {

    private static final String DIRECTORIO_BINARIO = System.getProperty("user.dir")
            + File.separator + "data" + File.separator + "binario";

    public static void guardarFactura(Factura factura) {
        File directorio = new File(DIRECTORIO_BINARIO);
        directorio.mkdirs();

        String nombreArchivo = "factura_" + factura.getNumeroFactura() + ".bin";
        File archivo = new File(directorio, nombreArchivo);

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo))) {
            oos.writeObject(factura);
        } catch (IOException e) {
            System.err.println("Error al guardar factura en binario: " + archivo.getName());
            e.printStackTrace();
        }
    }

    public static Factura[] cargarFacturas() {
        File directorio = new File(DIRECTORIO_BINARIO);
        if (!directorio.exists()) {
            return new Factura[0];
        }

        File[] archivos = directorio.listFiles(f -> f.getName().endsWith(".bin"));
        if (archivos == null || archivos.length == 0) {
            return new Factura[0];
        }

        Factura[] facturas = new Factura[archivos.length];

        for (int i = 0; i < archivos.length; i++) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivos[i]))) {
                facturas[i] = (Factura) ois.readObject();
            } catch (IOException | ClassNotFoundException e) {
                System.err.println("Error al leer factura binaria: " + archivos[i].getName());
                e.printStackTrace();
            }
        }

        return facturas;
    }
}
