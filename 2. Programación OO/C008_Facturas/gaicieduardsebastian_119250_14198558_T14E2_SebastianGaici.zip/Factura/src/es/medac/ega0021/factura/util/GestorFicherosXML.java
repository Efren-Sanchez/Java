package es.medac.ega0021.factura.util;

import java.io.File;
import java.io.FileWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import es.medac.ega0021.factura.model.Cliente;
import es.medac.ega0021.factura.model.Factura;
import es.medac.ega0021.factura.model.LineaFactura;
import es.medac.ega0021.factura.model.enums.IVA;

public final class GestorFicherosXML {

    private static final String DIRECTORIO_RAIZ = System.getProperty("user.dir");
    private static final String DIRECTORIO_FACTURAS = DIRECTORIO_RAIZ + File.separator + "data" + File.separator
            + "facturas";

    /***** MÉTODOS PÚBLICOS *****/
    public static void guardarFactura(Factura factura) {
        String nombreFichero = "factura_" + factura.getNumeroFactura() + ".xml";
        String rutaFichero = DIRECTORIO_FACTURAS + File.separator + nombreFichero;
        String facturaXML = generarFactura(factura);

        try (FileWriter fw = new FileWriter(rutaFichero)) {
            fw.write(facturaXML);
        } catch (Exception e) {
            System.err.println("Error al guardar la factura: ");
            e.printStackTrace();
        }
    }

    public static Factura[] cargarFacturas() {

        File directorioFacturas = new File(DIRECTORIO_FACTURAS);

        // Devolver un vector vacío si el directorio no existe
        if (!directorioFacturas.exists()) {
            return new Factura[0];
        }

        // Obtener todos los archivos .xml del directorio. Se hace uso de una expresión
        // lambda
        File[] facturasXML = directorioFacturas.listFiles(fichero -> fichero.getName().endsWith(".xml"));

        // Devolver un vector vacío si no hay archivos
        if (facturasXML == null || facturasXML.length == 0) {
            return new Factura[0];
        }

        // Crear vector de facturas con tamaño igual a la cantidad de facturas
        Factura[] facturas = new Factura[facturasXML.length];

        // Leer y parsear cada factura XML
        for (int i = 0; i < facturasXML.length; i++) {
            try {
                StringBuilder facturaXML = new StringBuilder();
                Scanner scanner = new Scanner(facturasXML[i]);

                while (scanner.hasNextLine()) {
                    facturaXML.append(scanner.nextLine()).append("\n");
                }

                scanner.close();

                facturas[i] = parsearFactura(facturaXML.toString());

            } catch (Exception e) {
                System.err.println("Error al leer/parsear la factura: " + facturasXML[i].getName());
                e.printStackTrace();
            }
        }

        return facturas;
    }

    public static Factura parsearFactura(String facturaXML) {
        Factura factura = new Factura();

        factura.setNumeroFactura(Integer.parseInt(extraerAtributo(facturaXML, "factura", "numeroFactura")));
        factura.setFechaEmision(LocalDateTime.parse(extraerContenido(facturaXML, "fechaEmision")));
        factura.setCliente(new Cliente(
                extraerContenido(facturaXML, "nombre"),
                extraerContenido(facturaXML, "idCliente")));

        // Extraer líneas
        String etiquetaInicio = "<linea";
        String etiquetaFin = "</linea>";
        int posicion = 0;

        while ((posicion = facturaXML.indexOf(etiquetaInicio, posicion)) != -1) {
            int inicioContenido = facturaXML.indexOf(">", posicion) + 1;
            int finContenido = facturaXML.indexOf(etiquetaFin, inicioContenido);
            String bloqueLinea = facturaXML.substring(posicion, finContenido + etiquetaFin.length());

            String articulo = extraerContenido(bloqueLinea, "articulo");
            int cantidad = Integer.parseInt(extraerContenido(bloqueLinea, "cantidad"));
            double precio = Double.parseDouble(extraerContenido(bloqueLinea, "precio"));
            IVA iva = IVA.valueOf(extraerContenido(bloqueLinea, "iva"));

            factura.agregarLinea(new LineaFactura(articulo, cantidad, precio, iva));

            posicion = finContenido + etiquetaFin.length();
        }

        return factura;
    }

    /***** MÉTODOS AUXILIARES *****/
    private static String generarFactura(Factura factura) {
        StringBuilder lineasFactura = new StringBuilder();

        // 👁️: No se puede utilizar un for each porque necesitamos el índice para el
        // número de línea
        for (int i = 0; i < factura.getcontadorLineas(); i++) {
            LineaFactura linea = factura.getLineasFactura()[i];
            lineasFactura.append("""
                    <linea numeroLinea="%d">
                        <articulo>%s</articulo>
                        <cantidad>%d</cantidad>
                        <precio>%.2f</precio>
                        <iva>%s</iva>
                    </linea>""".formatted(
                    i + 1,
                    linea.getArticulo(),
                    linea.getCantidad(),
                    linea.getPrecio(),
                    linea.getIva()).indent(8));
        }

        return """
                <?xml version="1.0" encoding="UTF-8"?>
                <factura numeroFactura="%d">
                    <fechaEmision>%s</fechaEmision>
                    <cliente>
                        <nombre>%s</nombre>
                        <idCliente>%s</idCliente>
                    </cliente>
                    <lineas>%n%s    </lineas>
                </factura>""".formatted(
                factura.getNumeroFactura(),
                factura.getFechaEmision().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                factura.getCliente().getNombre(),
                factura.getCliente().getId(),
                lineasFactura.toString());
    }

    // Devolver el contenido de una etiqueta XML
    private static String extraerContenido(String xml, String etiqueta) {
        String etiquetaApetura = "<" + etiqueta + ">";
        String etiquetaCierre = "</" + etiqueta + ">";

        int inicio = xml.indexOf(etiquetaApetura) + etiquetaApetura.length();
        int fin = xml.indexOf(etiquetaCierre, inicio);

        if (inicio == -1 || fin == -1)
            return "";

        return xml.substring(inicio, fin).trim();
    }

    private static String extraerAtributo(String xml, String etiqueta, String atributo) {
        String aperturaEtiqueta = "<" + etiqueta;

        int inicioEtiqueta = xml.indexOf(aperturaEtiqueta);
        int inicioAtributo = xml.indexOf(atributo + "=\"", inicioEtiqueta) + atributo.length() + 2;
        int finAtributo = xml.indexOf("\"", inicioAtributo);

        if (inicioEtiqueta == -1 || inicioAtributo == -1 || finAtributo == -1)
            return "";

        return xml.substring(inicioAtributo, finAtributo).trim();
    }
}
