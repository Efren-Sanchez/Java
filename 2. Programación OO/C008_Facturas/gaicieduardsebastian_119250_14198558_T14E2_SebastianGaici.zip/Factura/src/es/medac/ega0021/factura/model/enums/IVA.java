package es.medac.ega0021.factura.model.enums;

public enum IVA {
    NORMAL(21),
    REDUCIDO(10),
    SUPER_REDUCIDO(4),
    EXENTO(0);

    private final int porcentaje;

    IVA(int porcentaje) {
        this.porcentaje = porcentaje;
    }

    public int getPorcentaje() {
        return this.porcentaje;
    }
}
