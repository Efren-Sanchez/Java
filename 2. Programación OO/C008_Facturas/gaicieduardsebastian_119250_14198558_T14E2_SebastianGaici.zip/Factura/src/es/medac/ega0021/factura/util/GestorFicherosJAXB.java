package es.medac.ega0021.factura.util;

import java.io.File;

import es.medac.ega0021.factura.model.Factura;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;

public class GestorFicherosJAXB {
    
    private static final String DIRECTORIO_RAIZ = System.getProperty("user.dir");
    private static final String DIRECTORIO_FACTURAS = DIRECTORIO_RAIZ + File.separator + "data" + File.separator
            + "facturas_jaxb";
    
    public static void guardarFactura(Factura factura) {
        String nombreFichero = "factura_" + factura.getNumeroFactura() + ".xml";
        String rutaFichero = DIRECTORIO_FACTURAS + File.separator + nombreFichero;

        try {
            // Crear contexto JAXB
            JAXBContext context = JAXBContext.newInstance(Factura.class);
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            // Crear archivo destino
            File archivoFactura = new File(rutaFichero);

            // Guardar objeto como XML en el archivo
            marshaller.marshal(factura, archivoFactura);

        } catch (JAXBException e) {
            System.err.println("Error al guardar la factura:");
            e.printStackTrace();
        }
    }

    public static Factura leerFactura(String nombreFichero) {
        String rutaFichero = DIRECTORIO_FACTURAS + File.separator + nombreFichero;
        File archivoFactura = new File(rutaFichero);

        try {
            // Crear contexto JAXB
            JAXBContext context = JAXBContext.newInstance(Factura.class);
            Unmarshaller unmarshaller = context.createUnmarshaller();

            // Leer y convertir XML a objeto Factura
            return (Factura) unmarshaller.unmarshal(archivoFactura);

        } catch (JAXBException e) {
            System.err.println("Error al leer la factura:");
            e.printStackTrace();
            return null;
        }
    }

    public static Factura leerFactura(File archivoFactura) {
        try {
            // Crear contexto JAXB
            JAXBContext context = JAXBContext.newInstance(Factura.class);
            Unmarshaller unmarshaller = context.createUnmarshaller();

            // Leer y convertir XML a objeto Factura
            return (Factura) unmarshaller.unmarshal(archivoFactura);

        } catch (JAXBException e) {
            System.err.println("Error al leer la factura:");
            e.printStackTrace();
            return null;
        }
    }
}
