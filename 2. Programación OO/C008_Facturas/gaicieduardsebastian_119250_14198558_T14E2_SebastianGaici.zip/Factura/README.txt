# Parecer ser que JAXB fue eliminada del JDK en Java 11 (sobre 2018),
por lo que he buscado las dependencias manualmente y las he descargado.

# Para practicar un poco y tratar de coger buenas costumbres,
he creado un pequeño pom.xml a mano con las dependencias descargadas.
El fichero se llama pom.txt para evitar que VS Code trate de construirlo.