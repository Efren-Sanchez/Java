package es.medac.ega0021.factura;

import es.medac.ega0021.factura.model.Empresa;
import es.medac.ega0021.factura.model.Factura;
import es.medac.ega0021.factura.util.GestorFicherosXML;
import es.medac.ega0021.factura.view.Vista;

public class App {

    public static final String AUTOR = "ega0021@alu.medac.es";

    static Vista vista;
    static Empresa empresa;
    static Factura[] facturas;

    public static void main(String[] args) {

        vista = new Vista();
        empresa = new Empresa(
                "El Corte Inglés S.A.",
                "A28017895",
                "Calle Hermosilla 112, 28009 Madrid, España",
                "914 018 500",
                "clientes@elcorteingles.es");
        facturas = GestorFicherosXML.cargarFacturas();

        // Mostrar la pantalla de inicio y ejecutar la opción elegida
        switch (vista.mostrarPantallaInicio()) {
            case "crear" -> crearFactura();
            case "ver" -> verFactura();
            case "salir" -> System.exit(0);
        }
    }

    public static void crearFactura() {
        Factura factura = new Factura(empresa);

        vista.introducirDatosCliente(factura);
        vista.introducirLineasFactura(factura);
        vista.mostrarFactura(factura);

        GestorFicherosXML.guardarFactura(factura);
        vista.mostrarConfirmacionGuardado(factura);
    }

    public static void verFactura() {
        if (facturas.length == 0) {
            System.out.println("No hay facturas guardadas. Pulse ENTER para salir.");
            System.exit(0);
        }
        Factura facturaElegida = facturas[vista.mostrarSelectorFacturas(facturas) - 1];
        facturaElegida.setEmpresa(empresa);
        vista.mostrarFactura(facturaElegida);
    }
}