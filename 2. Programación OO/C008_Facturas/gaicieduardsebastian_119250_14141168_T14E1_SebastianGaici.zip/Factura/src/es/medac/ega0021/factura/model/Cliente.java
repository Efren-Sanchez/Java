package es.medac.ega0021.factura.model;

public class Cliente {

    /***** Atributos *****/
    private String nombre;
    private String id;

    /***** Constructores *****/
    public Cliente() {
        this.nombre = "";
        this.id = "";
    }

    public Cliente(String nombre, String id) {
        this.nombre = nombre;
        this.id = id;
    }

    public Cliente(Cliente c) {
        this.nombre = c.nombre;
        this.id = c.id;
    }

    /***** Getters y Setters *****/
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    /***** Métodos comunes *****/
    @Override
    public String toString() {
        return String.format("""
                Nombre: %s
                ID: %s""",
                nombre,
                id);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null | getClass() != obj.getClass())
            return false;
        
        Cliente objConvertido = (Cliente) obj;

        return this.nombre == objConvertido.nombre &&
                this.id == objConvertido.id;
    }
}
