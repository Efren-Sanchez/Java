package es.medac.ega0021.factura.model;

import es.medac.ega0021.factura.model.enums.IVA;

public class LineaFactura {

    /***** Atributos *****/
    private String articulo;
    private int cantidad;
    private double precio;
    private IVA iva;

    /***** Constructores *****/
    public LineaFactura() {
        this.articulo = "";
        this.cantidad = 0;
        this.precio = 0.0;
        this.iva = IVA.NORMAL;
    }

    public LineaFactura(String articulo, int cantidad, double precio, IVA iva) {
        this.articulo = articulo;
        this.cantidad = cantidad;
        this.precio = precio;
        this.iva = iva;
    }

    public LineaFactura(LineaFactura lf) {
        this.articulo = lf.articulo;
        this.cantidad = lf.cantidad;
        this.precio = lf.precio;
        this.iva = lf.iva;
    }

    /***** Getters y Setters *****/
    public String getArticulo() {
        return articulo;
    }

    public void setArticulo(String articulo) {
        this.articulo = articulo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public IVA getIva() {
        return iva;
    }

    public void setIva(IVA iva) {
        this.iva = iva;
    }

    /***** Métodos *****/
    public double calcularSubtotal() {
        return precio * cantidad;
    }

    public double calcularIVA() {
        return calcularSubtotal() * (iva.getPorcentaje() / 100.0);
    }

    public double calcularTotal() {
        return calcularSubtotal() + calcularIVA();
    }

    /***** Métodos comunes *****/
    @Override
    public String toString() {
        return String.format("""
                Articulo: %s
                Cantidad: %d
                Precio: %.2f €
                IVA: %d%%
                Subtotal: %.2f €
                Total: %.2f €""",
                articulo,
                cantidad,
                precio,
                iva.getPorcentaje(),
                calcularSubtotal(),
                calcularTotal());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;

        LineaFactura objConvertido = (LineaFactura) obj;

        return this.articulo == objConvertido.articulo &&
                this.cantidad == objConvertido.cantidad &&
                this.precio == objConvertido.precio &&
                this.iva == objConvertido.iva;
    }
}
