package es.medac.ega0021.factura.view;

import java.time.format.DateTimeFormatter;

final class Componentes {
    static final byte ANCHO_APP = 65;

    // Separadores visuales
    static final String SEPARADOR_BLOQUE = "=".repeat(ANCHO_APP);
    static final String SEPARADOR_CONTENIDO = "-".repeat(ANCHO_APP);

    // ANSI (colores)
    static final String ANSI_RESET = "\u001B[0m";
    static final String ANSI_AMARILLO = "\u001B[33m";
    static final String ANSI_ROJO = "\u001B[31m";

    // Mensajes
    static final String PREGUNTA_DATOS_CORRECTOS = "¿Son correctos los datos introducidos? (s/n): ";
    static final String PREGUNTA_NUEVA_LINEA = "¿Desea introducir más líneas a la factura? (s/n): ";

    static final String MENSAJE_REINTRODUCIR_DATOS = "\nPor favor, vuelva a ingresar los datos. ";

    static final String ERROR = ANSI_ROJO + "ERROR" + ANSI_RESET;
    static final String ERROR_PREGUNTA_SIN_RESPUESTA = "\n" + ERROR + " No ha resondido la pregunta.\n";
    static final String ERROR_CARACTER_INCORRECTO = "\n" + ERROR + " El carácter introducido no es correcto.\n";

    // Formato
    static final String PATRON_TOTAL = "\t\t\t\t %13s: %10.2f E";

    static final DateTimeFormatter FORMATO_FECHA_CORTA = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    static final DateTimeFormatter FORMATO_FECHA_COMPLETA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    // Componentes Reutilizables
    static final String PIE_TABLA_FACTURA = "+--------------+------------+-------------+-------------+-------+";

    /***** MÉTODOS *****/
    static void nombreBloque(String nombreBloque) {
        StringBuilder resultado = new StringBuilder();
        byte iteraciones = (byte) Math.max(0, (ANCHO_APP - nombreBloque.length()) / 2);
        for (byte i = 0; i < iteraciones; i++) {
            resultado.append(" ");
        }
        resultado.append(nombreBloque.toUpperCase());
        System.out.println(resultado.toString());
    }

    static void limpiarConsola() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    static void encabezadoTablaFactura() {
        System.out.println(PIE_TABLA_FACTURA);
        System.out.println("|   Artículo   |  Cantidad  |  Precio U.  |   Importe   |  IVA  |");
        System.out.println(PIE_TABLA_FACTURA);
    }
}