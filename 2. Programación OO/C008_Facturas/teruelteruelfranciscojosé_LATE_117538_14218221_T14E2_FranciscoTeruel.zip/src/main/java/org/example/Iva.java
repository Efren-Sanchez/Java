package org.example;

public enum Iva{
    SUPER_REDUCIDO(4),
    REDUCIDO(10),
    NORMAL(21);

    private final int porcentaje;

    Iva(int porcentaje) {
        this.porcentaje = porcentaje;
    }

    public int getPorcentaje() {
        return porcentaje;
    }
}