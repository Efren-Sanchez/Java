package org.example;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.*;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.LocalDateTime;

@XmlAccessorType(XmlAccessType.FIELD)
public class Factura implements Serializable {
    @XmlElement(name = "serialVersionUID")
    private static final long serialVersionUID = 1L;
    private final String empresa;
    private final String direccionEmpresa;
    private final String cifEmpresa;
    private final String telefonoEmpresa;
    private final String emailEmpresa;
    private final Cliente cliente;
    @XmlJavaTypeAdapter(LocalDateTimeAdapter.class)
    private final LocalDateTime fechaHora;
    private final int numeroFactura;
    @XmlElementWrapper(name = "lineas")
    @XmlElement(name = "linea")
    private final List<LineaFactura> lineas;
    private double totalFactura;

    public Factura(String empresa, String direccionEmpresa, String cifEmpresa,
                   String telefonoEmpresa, String emailEmpresa, String cliente,
                   String nifCliente, int numeroFactura) {
        this.empresa = empresa;
        this.direccionEmpresa = direccionEmpresa;
        this.cifEmpresa = cifEmpresa;
        this.telefonoEmpresa = telefonoEmpresa;
        this.emailEmpresa = emailEmpresa;
        this.cliente = new Cliente(cliente,nifCliente);
        this.fechaHora = LocalDateTime.now();
        this.numeroFactura = numeroFactura;
        this.lineas = new ArrayList<>();
        this.totalFactura = 0.0;
    }

    public void agregarLinea(LineaFactura linea) {
        lineas.add(linea);
        totalFactura += linea.getTotalLinea();
    }

    // Getters
    public LocalDateTime getFechaHora() { return fechaHora; }
    public int getNumero() { return numeroFactura; }
    public List<LineaFactura> getLineas() { return lineas; }
    public double getTotal() { return totalFactura; }
    public String getEmpresa() { return empresa; }
    public Cliente getCliente() { return cliente; }

    public double getTotalFactura() {
        return totalFactura;
    }

    public int getNumeroFactura() {
        return numeroFactura;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getCifEmpresa() {
        return cifEmpresa;
    }

    public String getDireccionEmpresa() {
        return direccionEmpresa;
    }

    public String getEmailEmpresa() {
        return emailEmpresa;
    }


    public String getTelefonoEmpresa() {
        return telefonoEmpresa;
    }

    @Override
    public String toString() {
        return "Factura{" +
                "empresa='" + empresa + '\'' +
                ", direccionEmpresa='" + direccionEmpresa + '\'' +
                ", cifEmpresa='" + cifEmpresa + '\'' +
                ", telefonoEmpresa='" + telefonoEmpresa + '\'' +
                ", emailEmpresa='" + emailEmpresa + '\'' +
                ", cliente='" + cliente.getNombre() + '\'' +
                ", nifCliente='" + cliente.getNif() + '\'' +
                ", fechaHora=" + fechaHora +
                ", numeroFactura=" + numeroFactura +
                ", lineas=" + lineas +
                ", totalFactura=" + totalFactura +
                '}';
    }

}
