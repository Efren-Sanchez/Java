package org.example;

import java.io.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static org.example.DocumentGenerator.BIN_FILE;

public class GestorFacturas {

    protected static List<Factura> facturas = new ArrayList<>();
    static int siguienteNumero = 1;

    public static void main(String[] args) {
        cargarFacturas();
        mostrarMenu();
    }

    private static void cargarFacturas() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(BIN_FILE))) {
            facturas = (List<Factura>) ois.readObject();
            if (!facturas.isEmpty()) {
                siguienteNumero = facturas.get(facturas.size() - 1).getNumero() + 1;
            }
        } catch (FileNotFoundException e) {
            System.out.println("No se encontró archivo previo. Comenzando desde factura #1");
        } catch (Exception e) {
            System.err.println("Error cargando facturas: " + e.getMessage());
        }
    }

    private static void guardarFacturasJABAX() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(BIN_FILE))) {
            oos.writeObject(facturas);
            DocumentGenerator.generarXML();
            DocumentGenerator.generarJSON();
        } catch (Exception e) {
            System.err.println("Error guardando facturas: " + e.getMessage());
        }
    }
    // En el metodo guardarFacturas()
    private static void guardarFacturas() {
        try {
            // Guardar en binario
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(BIN_FILE))) {
                oos.writeObject(facturas);
            }

            // Generar XML
            DocumentGeneratorXML.generarXML();

        } catch (Exception e) {
            System.err.println("Error guardando facturas: " + e.getMessage());
        }
    }

    private static void mostrarMenu() {
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n--- MENÚ GESTIÓN DE FACTURAS ---");
            System.out.println("1. Crear nueva factura");
            System.out.println("2. Mostrar todas las facturas");
            System.out.println("3. Salir");
            System.out.print("Seleccione opción: ");

            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    crearFactura(sc);
                    break;
                case 2:
                    mostrarFacturas();
                    break;
                case 3:
                    guardarFacturas();
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción inválida");
            }
        } while (opcion != 3);
    }

    private static void crearFactura(Scanner sc) {
        System.out.println("\nNUEVA FACTURA:");

        // Datos de la empresa
        System.out.print("Razón social empresa: ");
        String empresa = sc.nextLine();
        System.out.print("Dirección empresa: ");
        String direccionEmpresa = sc.nextLine();
        System.out.print("CIF empresa: ");
        String cifEmpresa = sc.nextLine();
        System.out.print("Teléfono empresa: ");
        String telefonoEmpresa = sc.nextLine();
        System.out.print("Email empresa: ");
        String emailEmpresa = sc.nextLine();

        // Datos del cliente

        System.out.print("Nombre cliente: ");
        String cliente = sc.nextLine();

        System.out.print("NIF/CIF cliente: ");
        String nifCliente = sc.nextLine();

        Factura nuevaFactura = new Factura(empresa, direccionEmpresa, cifEmpresa,
                telefonoEmpresa, emailEmpresa, cliente,
                nifCliente, siguienteNumero++);

        // Añadir líneas de factura
        boolean agregarMas = true;
        while (agregarMas) {
            System.out.print("\nArtículo: ");
            String articulo = sc.nextLine();
            System.out.print("Cantidad: ");
            int cantidad = sc.nextInt();
            System.out.print("Precio unitario: ");
            double precio = sc.nextDouble();
            System.out.print("IVA (1-SuperReducido 2-Reducido 3-Normal): ");
            Iva iva = switch (sc.nextInt()) {
                case 1 -> Iva.SUPER_REDUCIDO;
                case 2 -> Iva.REDUCIDO;
                default -> Iva.NORMAL;
            };

            nuevaFactura.agregarLinea(new LineaFactura(articulo, cantidad, precio, iva));

            System.out.print("¿Agregar otra línea? (s/n): ");
            agregarMas = sc.next().equalsIgnoreCase("s");
            sc.nextLine();
        }

        facturas.add(nuevaFactura);
        System.out.println("Factura creada exitosamente!");
    }

    private static void mostrarFacturas() {
        if (facturas.isEmpty()) {
            System.out.println("No hay facturas registradas");
            return;
        }

        for (Factura f : facturas) {
            System.out.println("\n=================================");
            System.out.println("Factura #" + f.getNumero());
            System.out.println("Fecha: " + f.getFechaHora().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")));
            System.out.println("Cliente: " + f.getCliente().getNombre());
            System.out.println("---------------------------------");
            for (LineaFactura linea : f.getLineas()) {
                System.out.printf("%-20s %3d x %6.2f€ (IVA %2d%%) = %8.2f€\n",
                        linea.getArticulo().getNombre(),
                        linea.getCantidad(),
                        linea.getArticulo().getPrecio(),
                        linea.getArticulo().getIva().getPorcentaje(),
                        linea.getTotalLinea());
            }
            System.out.println("---------------------------------");
            System.out.printf("TOTAL FACTURA: %10.2f€\n", f.getTotal());
            System.out.println("=================================");
        }
    }
}