package org.example;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.File;

public class DocumentGeneratorXML {
    public static final String XML_FILE = "facturas.xml";

    public static void generarXML() {
        try {
            JAXBContext context = JAXBContext.newInstance(FacturasWrapper.class);
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

            FacturasWrapper wrapper = new FacturasWrapper();
            wrapper.setFacturas(GestorFacturas.facturas);

            marshaller.marshal(wrapper, new File(XML_FILE));
        } catch (Exception e) {
            System.err.println("Error generando XML: " + e.getMessage());
        }
    }

    public static void cargarXML() {
        try {
            JAXBContext context = JAXBContext.newInstance(FacturasWrapper.class);
            Unmarshaller unmarshaller = context.createUnmarshaller();

            FacturasWrapper wrapper = (FacturasWrapper) unmarshaller.unmarshal(new File(XML_FILE));
            GestorFacturas.facturas = wrapper.getFacturas();

            // Actualizar el siguiente número
            if (!GestorFacturas.facturas.isEmpty()) {
                GestorFacturas.siguienteNumero =
                        GestorFacturas.facturas.get(GestorFacturas.facturas.size() - 1)
                                .getNumeroFactura() + 1;
            }
        } catch (Exception e) {
            System.err.println("Error cargando XML: " + e.getMessage());
        }
    }
}