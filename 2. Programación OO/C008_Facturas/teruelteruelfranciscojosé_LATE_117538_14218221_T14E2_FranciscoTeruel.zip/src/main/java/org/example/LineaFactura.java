package org.example;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;


@XmlAccessorType(XmlAccessType.FIELD)
class LineaFactura implements Serializable {
    private Articulo articulo;
    private int cantidad;
    private double totalLinea;

    public LineaFactura(String articulo, int cantidad, double precio, Iva iva) {
        this.articulo = new Articulo(articulo,precio,iva);
        this.cantidad = cantidad;
        calcularTotal();
    }

    private void calcularTotal() {
        totalLinea = cantidad * articulo.getPrecio() * (1 + articulo.getIva().getPorcentaje() / 100.0);
    }

    // Getters
    public Articulo getArticulo() { return articulo; }
    public int getCantidad() { return cantidad; }
    public double getTotalLinea() { return totalLinea; }
}
