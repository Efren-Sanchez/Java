import java.io.IOException;
// import java.time.LocalDateTime;

public class Main {
    private static Factura[] facturas = new Factura[10];
    private static int numFacturas = 0;
    private static int siguienteNumeroFactura = 1;

    public static void main(String[] args) {
        cargarDatosIniciales();

        boolean salir = false;
        while (!salir) {
            mostrarMenu();
            int opcion = UtilidadesFactura.leerInt("Selecciona una opción para continuar: ");

            switch (opcion) {
                case 1:
                    crearFactura();
                    break;
                case 2:
                    mostrarFacturas();
                    break;
                case 3:
                    guardarXML();
                    break;
                case 4:
                    guardarBinario();
                    break;
                case 5:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción elegida no válida. Selecciona una opción del menú. (1-5)");
            }
        }

        guardarBinario();
        System.out.println("Fin del programa.");
    }

    private static void cargarDatosIniciales() {
        try {
            Factura[] cargadas = GestorFacturasBinario.cargarFacturas();
            if (cargadas != null) {
                facturas = cargadas;
                numFacturas = cargadas.length;
                if (numFacturas > 0) {
                    siguienteNumeroFactura = facturas[numFacturas - 1].getNumeroFactura() + 1;
                }
            }
        } catch (Exception e) {
            System.out.println("No se han encontrado registros anteriores. Se procedera a crear una nueva factura.");
        }
    }

    private static void mostrarMenu() {
        UtilidadesFactura.limpiarPantalla();
        System.out.println("\n--- GENERADOR DE FACTURAS SUPERWEBINARS S.L. ---");
        System.out.println("1. Crear nueva factura");
        System.out.println("2. Mostrar facturas");
        System.out.println("3. Guardar facturas en XML");
        System.out.println("4. Guardar facturas en binario");
        System.out.println("5. Salir");
    }

    private static void crearFactura() {
        UtilidadesFactura.limpiarPantalla();
        System.out.println("\n--- NUEVA FACTURA ---");
        String nombreCliente = UtilidadesFactura.leerString("Nombre del cliente: ");
        String nifCliente = UtilidadesFactura.leerString("NIF del cliente: ");

        Factura factura = new Factura(nombreCliente, nifCliente, siguienteNumeroFactura++);

        boolean añadirMas = true;
        while (añadirMas) {
            System.out.println("\nAñadiendo línea de factura:");
            String articulo = UtilidadesFactura.leerString("Artículo: ");
            int cantidad = UtilidadesFactura.leerInt("Cantidad: ");
            double precio = UtilidadesFactura.leerDouble("Precio unitario: ");

            System.out.println("Tipo de IVA:");
            System.out.println("1. Superreducido (4%)");
            System.out.println("2. Reducido (10%)");
            System.out.println("3. Normal (21%)");
            int opcionIva = UtilidadesFactura.leerInt("Selecciona: ");

            TipoIVA iva = switch (opcionIva) {
                case 1 -> TipoIVA.SUPER_REDUCIDO;
                case 2 -> TipoIVA.REDUCIDO;
                case 3 -> TipoIVA.NORMAL;
                default -> TipoIVA.NORMAL;
            };

            factura.añadirLinea(new LineaFactura(articulo, cantidad, precio, iva));

            String respuesta = UtilidadesFactura.leerString("¿Deseas añadir otra línea? (s/n): ");
            añadirMas = respuesta.equalsIgnoreCase("s");
        }

        if (numFacturas == facturas.length) {
            Factura[] nuevo = new Factura[facturas.length * 2];
            System.arraycopy(facturas, 0, nuevo, 0, facturas.length);
            facturas = nuevo;
        }
        facturas[numFacturas++] = factura;
        System.out.println("\nFactura creada:\n" + factura);
        UtilidadesFactura.leerString("\nPulsa la tecla Enter para continuar...");
    }

    private static void mostrarFacturas() {
        UtilidadesFactura.limpiarPantalla();
        if (numFacturas == 0) {
            System.out.println("No existen facturas registradas en el sistema.");
            UtilidadesFactura.leerString("\nPulsa la tecla Enter para continuar...");
            return;
        }

        System.out.println("\n--- LISTADO DE FACTURAS ---");
        for (int i = 0; i < numFacturas; i++) {
            System.out.println(facturas[i]);
            System.out.println("----------------------------------");
        }
        UtilidadesFactura.leerString("\nPulsa la tecla Enter para continuar...");
    }

    private static void guardarXML() {
        try {
            GestorFacturasXML.guardarFacturasXML(facturas, numFacturas);
            System.out.println("Facturas guardadas en formato XML exitosamente.");
        } catch (Exception e) {
            System.out.println("Error al guardar en formato XML: " + e.getMessage());
        }
        UtilidadesFactura.leerString("\nPulsa la tecla Enter para continuar...");
    }

    private static void guardarBinario() {
        try {
            GestorFacturasBinario.guardarFacturas(facturas, numFacturas);
            System.out.println("Facturas guardadas en formato binario exitosamente.");
        } catch (IOException e) {
            System.out.println("Error al guardar en formato binario: " + e.getMessage());
        }
    }
}